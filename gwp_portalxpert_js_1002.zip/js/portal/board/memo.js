	//문자수계산
	function getByteLength(s,b,i,c){
		//for(b=i=0;c=s.charCodeAt(i++);b+=c>>11?3:c>>7?2:1);
		for(b=i=0;c=s.charCodeAt(i++);b+=c>>7?2:1);
		return b;
	}
	
	//메모 리셋버튼
	function init(){
		
		$("#memotext").val('');
		$(".presNum").text('0');
		$(".listbox2").empty();
	}
	
	function fn_link_page(pageNo) {
		document.sendForm.pageUnit.value = pageUnit;
		document.sendForm.pageIndex.value = pageNo;
		document.sendForm.submit();
	}	
	
	function fnSearchList(){
		pageUnit = $('#list_cnt').val();
		document.sendForm.pageIndex.value = '1';
		document.sendForm.searchCondition.value = $("#search_gubun").val();
		document.sendForm.searchKeyword.value = $("#keyword").val().replace(/&quot;/g,"\"");

		document.sendForm.pageUnit.value = pageUnit;
		document.sendForm.submit();		
	}
	
	//부서선택
	function callbackOpenDept(data){
		
		var json = $.parseJSON(data);		
		for (var i=0; i < json.length; i++)
		{
			var contains = false;
			$obj = $('#lsb_dept li');
	    	for( var j=0; j < $obj.length; j++)
	    	{
	    		if ($obj.eq(j).attr("id") == json[i].id)
				{
	    			contains = true;
	    			break;
				}
	    	}	    	
	    	if (!contains) $('#lsb_dept').append('<li id="'+json[i].id+'"><a style="cursor:pointer;" onclick="javascript:fnOpenDeptListRemove(\''+json[i].id+'\')" ></a>'+json[i].name+'</li>');
		}
	}
	
	//부서삭제
	function fnOpenDeptListRemove(id)
	{
		$("#lsb_dept #"+id).remove();
	}
	
	//사용자 선택
	function callbackOpenPerson(data){

		var json = $.parseJSON(data);		
		for (var i=0; i < json.length; i++)
		{
			var contains = false;
			$obj = $('#lsb_person li');
	    	for( var j=0; j < $obj.length; j++)
	    	{
	    		if ($obj.eq(j).attr("id") == json[i].id)
				{
	    			contains = true;
	    			break;
				};
	    	};	
	    	if (!contains) $('#lsb_person').append('<li id="'+json[i].id+'"><a style="cursor:pointer;" onclick="javascript:fnOpenPersonListRemove(\''+json[i].id+'\')" ></a>'+json[i].ou+' '+json[i].name+'</li>');
		};
	}	
	
	//사용자삭제
	function fnOpenPersonListRemove(id)
	{
	   $("#lsb_person #"+id).remove();
	}	
	
	//발송버튼
	function send(){
		
		var recvrInfo =  new Array();
		for (var i=0;i<$("#lsb_person li").size();i++) {
			var memoReceiver = {
					'recvSeq'		:	'',
					'recvrId'		:	($("#lsb_person li").eq(i).attr("id")),	//수신자
					'recvDeptCode'	:	'',
					'cnfmDttm'		:	null
			};
			recvrInfo[i] = memoReceiver;
		}
		for (var i=0;i<$("#lsb_dept li").size();i++) {
			var memoReceiver = {
					'recvSeq'		:	'',
					'recvrId'		:	'DEPT',
					'recvDeptCode'	:	($("#lsb_dept li").eq(i).attr("id")),	//조직
					'cnfmDttm'		:	null
			};
			recvrInfo[i] = memoReceiver;
		}
		
		var personSize = $("#lsb_person li").size();
		var deptSize = $("#lsb_dept li").size();
		if(personSize == 0 && deptSize == 0){
			alert("발송대상을 선택하세요.");
			return;
		}
		
		var memoText = $("#memotext").val();
		if(memoText == "" || memoText == "100자 이내로 작성해 주십시오."){
			alert("내용을 입력하세요");
			return;
		}
		
		if(!confirm("발송하시겠습니까?")){
			return;
		}			
		
		var memoVO = {
				'adsrId'	:	'',							//보내는이
				'adsrCtt'	:	memoText,				//메모내용
				'recvrInfo'	:	recvrInfo
		};
		
		PortalCommon.getJson({
			url : WEB_HOME+"/board/memo/sendMemo.jdo",
			data : {'data' : JSON.stringify(memoVO)},
		    type : 'POST',
			success : function(data) {
				fnSearchList();
			}
		});
			
	} //end send
	
		//ready
	$("document").ready(function(){
		$("#sendPopup").hide();
		$("#recvPopup").hide();
		
		$('#list_cnt').val(pageUnit);
		
		$('#search').click(function() {//검색
			fnSearchList();
		});		
		
		$('#list_cnt').change(function() {//조회갯수
			fnSearchList();
		});			
		
		
		$("#recvTab").click(function(){
			location.href = WEB_HOME+"/board/memo/recvMemoList.jdo";
		});
		
		$("#sendTab").click(function(){
			location.href = WEB_HOME+"/board/memo/sendMemoList.jdo";
		});
		
		//메모TextArea
		$("#memotext").on({
			"click"		:	function(){(($("#memotext").val())==="100자 이내로 작성해 주십시오.")?$("#memotext").val(''):null},
			"blur"		:	function(){(getByteLength($(this).val()))?null:$("#memotext").val("100자 이내로 작성해 주십시오.");},
			"keyup"		:	function(){
				var cs = getByteLength($(this).val());
				$(".presNum").text(cs);
				if (cs>100) {alert("100자 이내로 작성해 주십시오.");}
			}
		});
		
		
		$("#btn_all").click(function(){
			$("#lsb_dept").empty();
			$("#lsb_person").empty();
			$('#lsb_dept').append('<li id="ALL"><a style="cursor:pointer;" onclick="javascript:fnOpenDeptListRemove(\'ALL\')" ></a>전체</li>');
		});
		
		$("#btn_dept").click(function(){
			for (var i=0;i<$("#lsb_dept li").size();i++) {
				if($("#lsb_dept li").eq(i).attr("id") == 'ALL') return;
			}			
			PortalCommon.popupWindowCenter(WEB_HOME+'/board/organization/organizationChart.jdo?type=1&callback=callbackOpenDept', '부서선택',900,520);
		});
		
		$("#btn_person").click(function(){
			for (var i=0;i<$("#lsb_dept li").size();i++) {
				if($("#lsb_dept li").eq(i).attr("id") == 'ALL') return;
			}
			PortalCommon.popupWindowCenter(WEB_HOME+'/board/organization/organizationChart.jdo?type=2&callback=callbackOpenPerson', '사용자선택',900,520);
		});		
	});	
/**
 * Web Editor rendering function
 * @param res_home
 * @param id
 * @param param
 */
function fnMakeWebEditor(res_home, id, param){
	var CrossEditor = new NamoSE(id);
	CrossEditor.params.Width = "100%";
	CrossEditor.params.UserLang = "auto";
	CrossEditor.params.FullScreen = false;
	//CrossEditor.EditorStart();	
}
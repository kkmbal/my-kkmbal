package portalxpert.common.vo;

import java.io.Serializable;
import java.util.List;

public class UserInfoVO implements Serializable{

	private static final long serialVersionUID = 6549629172358012038L;
	
	private String id;
	private String name;
	private String deptCode;
	private String deptName;
	private String deptFname;
	private String nickName;
	//private String resinumber;
	//private String displayname;
	//private String oucode;
	//private String ou;
	//private String orgfullname;
	//private String parentoucode;
	//private String titlecode;
	//private String titlename;
	private String mail;
	//private String intermail;
	//private String telephonenumber;
	//private String titlegrade;
	//private String etitlegrade;
	//private String jobtitle;
	//private String svid;
	//private String positioncode;
	//private String position;
	//private String eorder;
	//private String titleorposition;
	//private String mobile;
	//private String adddate;
	//private String changedate;
	//private String sid;
	//private String userKey;
	//private String userRepImg;
	//private String tmlnreaddttm; 
	//private String msgYN;
	//private String passwd;
	//private List<String> authCd;
	//private String authCdStr;
	//private String menuConts;
	
	public String getId() {
		return id;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptFname() {
		return deptFname;
	}
	public void setDeptFname(String deptFname) {
		this.deptFname = deptFname;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	
	

	
	
}

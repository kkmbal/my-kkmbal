package portalxpert.board.board100.vo;

public class BbsNotiSurveyRsltVO {
	
	private String notiId;
	private int mCnt;
	private int surveyNo;
	private int answExmplNo;
	private int eCnt;
	private int iCnt;
	private int sCnt;
	
	//엑셀다운로드
	private String excelDivn;
	private int excelSurveyNo;
	private String answConts;
	
	public String getNotiId() {
		return notiId;
	}
	public void setNotiId(String notiId) {
		this.notiId = notiId;
	}
	public int getmCnt() {
		return mCnt;
	}
	public void setmCnt(int mCnt) {
		this.mCnt = mCnt;
	}
	public int getSurveyNo() {
		return surveyNo;
	}
	public void setSurveyNo(int surveyNo) {
		this.surveyNo = surveyNo;
	}
	public int getAnswExmplNo() {
		return answExmplNo;
	}
	public void setAnswExmplNo(int answExmplNo) {
		this.answExmplNo = answExmplNo;
	}
	public int geteCnt() {
		return eCnt;
	}
	public void seteCnt(int eCnt) {
		this.eCnt = eCnt;
	}
	public int getiCnt() {
		return iCnt;
	}
	public void setiCnt(int iCnt) {
		this.iCnt = iCnt;
	}
	public int getsCnt() {
		return sCnt;
	}
	public void setsCnt(int sCnt) {
		this.sCnt = sCnt;
	}
	public String getExcelDivn() {
		return excelDivn;
	}
	public void setExcelDivn(String excelDivn) {
		this.excelDivn = excelDivn;
	}
	public int getExcelSurveyNo() {
		return excelSurveyNo;
	}
	public void setExcelSurveyNo(int excelSurveyNo) {
		this.excelSurveyNo = excelSurveyNo;
	}
	public String getAnswConts() {
		return answConts;
	}
	public void setAnswConts(String answConts) {
		this.answConts = answConts;
	}
		
	
}

package portalxpert.board.board100.vo;

public class BbsEdcTgtInfoVO {
	private String notiId;
	private String reqSeq;
	private String tgtSeq;
	private String userName;
	private String telenumber;
	private String regrId;
	private String regrName;
	
	
	public String getRegrId() {
		return regrId;
	}
	public void setRegrId(String regrId) {
		this.regrId = regrId;
	}
	public String getRegrName() {
		return regrName;
	}
	public void setRegrName(String regrName) {
		this.regrName = regrName;
	}
	public String getNotiId() {
		return notiId;
	}
	public void setNotiId(String notiId) {
		this.notiId = notiId;
	}
	public String getReqSeq() {
		return reqSeq;
	}
	public void setReqSeq(String reqSeq) {
		this.reqSeq = reqSeq;
	}
	public String getTgtSeq() {
		return tgtSeq;
	}
	public void setTgtSeq(String tgtSeq) {
		this.tgtSeq = tgtSeq;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTelenumber() {
		return telenumber;
	}
	public void setTelenumber(String telenumber) {
		this.telenumber = telenumber;
	}
	
	
}

package portalxpert.board.board100.vo;

public class BbsEdcReqInfoVO {
	private String notiId;
	private String reqSeq;
	private String deptCode;
	private String deptName;
	private String edcDttm;
	private String edcTimeDiv;
	private String reqStatCode;
	private String regrId;
	private String regrName;
	private String notiTitle;
	private String edcType;
	private String edcCnt;
	private String edcTgtCnt;
	private String reqDeptCnt; 
	private String edcEnd;
	private String userName;
	private String updDttm;
	private String regDttm;
	private String rnum;
	
	
	public String getRegDttm() {
		return regDttm;
	}
	public void setRegDttm(String regDttm) {
		this.regDttm = regDttm;
	}
	public String getUpdDttm() {
		return updDttm;
	}
	public void setUpdDttm(String updDttm) {
		this.updDttm = updDttm;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEdcEnd() {
		return edcEnd;
	}
	public void setEdcEnd(String edcEnd) {
		this.edcEnd = edcEnd;
	}
	public String getRnum() {
		return rnum;
	}
	public void setRnum(String rnum) {
		this.rnum = rnum;
	}
	public String getReqDeptCnt() {
		return reqDeptCnt;
	}
	public void setReqDeptCnt(String reqDeptCnt) {
		this.reqDeptCnt = reqDeptCnt;
	}
	public String getNotiTitle() {
		return notiTitle;
	}
	public void setNotiTitle(String notiTitle) {
		this.notiTitle = notiTitle;
	}
	public String getEdcType() {
		return edcType;
	}
	public void setEdcType(String edcType) {
		this.edcType = edcType;
	}
	public String getEdcCnt() {
		return edcCnt;
	}
	public void setEdcCnt(String edcCnt) {
		this.edcCnt = edcCnt;
	}
	public String getEdcTgtCnt() {
		return edcTgtCnt;
	}
	public void setEdcTgtCnt(String edcTgtCnt) {
		this.edcTgtCnt = edcTgtCnt;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getRegrId() {
		return regrId;
	}
	public void setRegrId(String regrId) {
		this.regrId = regrId;
	}
	public String getRegrName() {
		return regrName;
	}
	public void setRegrName(String regrName) {
		this.regrName = regrName;
	}
	public String getNotiId() {
		return notiId;
	}
	public void setNotiId(String notiId) {
		this.notiId = notiId;
	}
	public String getReqSeq() {
		return reqSeq;
	}
	public void setReqSeq(String reqSeq) {
		this.reqSeq = reqSeq;
	}
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public String getEdcDttm() {
		return edcDttm;
	}
	public void setEdcDttm(String edcDttm) {
		this.edcDttm = edcDttm;
	}
	public String getEdcTimeDiv() {
		return edcTimeDiv;
	}
	public void setEdcTimeDiv(String edcTimeDiv) {
		this.edcTimeDiv = edcTimeDiv;
	}
	public String getReqStatCode() {
		return reqStatCode;
	}
	public void setReqStatCode(String reqStatCode) {
		this.reqStatCode = reqStatCode;
	}
	
	
	
}

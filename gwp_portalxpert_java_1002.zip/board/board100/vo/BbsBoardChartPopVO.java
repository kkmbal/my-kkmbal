package portalxpert.board.board100.vo;

public class BbsBoardChartPopVO {
	private String boardId;
	private String boardTp;
	private String boardOwnrId;
	private String boardOwnrName;
	private String boardName;
	public String getBoardId() {
		return boardId;
	}
	public void setBoardId(String boardId) {
		this.boardId = boardId;
	}
	public String getBoardTp() {
		return boardTp;
	}
	public void setBoardTp(String boardTp) {
		this.boardTp = boardTp;
	}
	public String getBoardOwnrId() {
		return boardOwnrId;
	}
	public void setBoardOwnrId(String boardOwnrId) {
		this.boardOwnrId = boardOwnrId;
	}
	public String getBoardOwnrName() {
		return boardOwnrName;
	}
	public void setBoardOwnrName(String boardOwnrName) {
		this.boardOwnrName = boardOwnrName;
	}
	public String getBoardName() {
		return boardName;
	}
	public void setBoardName(String boardName) {
		this.boardName = boardName;
	}
	
}

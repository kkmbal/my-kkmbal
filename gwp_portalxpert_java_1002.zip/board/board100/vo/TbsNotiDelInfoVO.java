package portalxpert.board.board100.vo;


public class TbsNotiDelInfoVO {
	
	private String mvpKey;
	private int seqNo;
	private String mvpSkey;
	private String formt;
	private String titleImgNo;
	private String runTime;
	private String orginlFileNm;
	private String thumbTime;
	private String state;
	private String mvpFileNm;
	private String titleFileNm;
	private String thumbFile1;
	private String thumbFile2;
	private String thumbFile3;
	private String thumbFile4;
	private String thumbFile5;
	private String thumbFile6;
	private String rgsde;
	private String mvpHighFileNm;
	public String getMvpKey() {
		return mvpKey;
	}
	public void setMvpKey(String mvpKey) {
		this.mvpKey = mvpKey;
	}
	public int getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}
	public String getMvpSkey() {
		return mvpSkey;
	}
	public void setMvpSkey(String mvpSkey) {
		this.mvpSkey = mvpSkey;
	}
	public String getFormt() {
		return formt;
	}
	public void setFormt(String formt) {
		this.formt = formt;
	}
	public String getTitleImgNo() {
		return titleImgNo;
	}
	public void setTitleImgNo(String titleImgNo) {
		this.titleImgNo = titleImgNo;
	}
	public String getRunTime() {
		return runTime;
	}
	public void setRunTime(String runTime) {
		this.runTime = runTime;
	}
	public String getOrginlFileNm() {
		return orginlFileNm;
	}
	public void setOrginlFileNm(String orginlFileNm) {
		this.orginlFileNm = orginlFileNm;
	}
	public String getThumbTime() {
		return thumbTime;
	}
	public void setThumbTime(String thumbTime) {
		this.thumbTime = thumbTime;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getMvpFileNm() {
		return mvpFileNm;
	}
	public void setMvpFileNm(String mvpFileNm) {
		this.mvpFileNm = mvpFileNm;
	}
	public String getTitleFileNm() {
		return titleFileNm;
	}
	public void setTitleFileNm(String titleFileNm) {
		this.titleFileNm = titleFileNm;
	}
	public String getThumbFile1() {
		return thumbFile1;
	}
	public void setThumbFile1(String thumbFile1) {
		this.thumbFile1 = thumbFile1;
	}
	public String getThumbFile2() {
		return thumbFile2;
	}
	public void setThumbFile2(String thumbFile2) {
		this.thumbFile2 = thumbFile2;
	}
	public String getThumbFile3() {
		return thumbFile3;
	}
	public void setThumbFile3(String thumbFile3) {
		this.thumbFile3 = thumbFile3;
	}
	public String getThumbFile4() {
		return thumbFile4;
	}
	public void setThumbFile4(String thumbFile4) {
		this.thumbFile4 = thumbFile4;
	}
	public String getThumbFile5() {
		return thumbFile5;
	}
	public void setThumbFile5(String thumbFile5) {
		this.thumbFile5 = thumbFile5;
	}
	public String getThumbFile6() {
		return thumbFile6;
	}
	public void setThumbFile6(String thumbFile6) {
		this.thumbFile6 = thumbFile6;
	}
	public String getRgsde() {
		return rgsde;
	}
	public void setRgsde(String rgsde) {
		this.rgsde = rgsde;
	}
	public String getMvpHighFileNm() {
		return mvpHighFileNm;
	}
	public void setMvpHighFileNm(String mvpHighFileNm) {
		this.mvpHighFileNm = mvpHighFileNm;
	}
	
}

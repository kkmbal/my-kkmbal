/**
 * 
 */
package portalxpert.board.memo.sc.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import portalxpert.board.memo.mapper.MemoMapper;
import portalxpert.board.memo.sc.MemoService;
import portalxpert.board.memo.vo.MemoReceiverVO;
import portalxpert.board.memo.vo.MemoVO;
import portalxpert.common.config.Constant;
import portalxpert.common.utils.CommUtil;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * <pre>
 * 쪽지 서비스 구현
 * </pre>
 * 
 * portalxpert.board.memo.sc.impl MemoServiceImpl.java
 * 
 * @author crossent
 * @since 2014. 9. 5.
 * 
 */
@Service("memoService")
public class MemoServiceImpl extends EgovAbstractServiceImpl implements MemoService {

	@Resource(name = "memoMapper")
	private MemoMapper memoMapper;

	/**
	 * <pre>
	 * 발송목록
	 * </pre>
	 * 
	 * @author 안근창
	 * @since 2014. 8. 25.
	 * @Method Name : listSend
	 * @param memoVO
	 * @return
	 */
	public List<MemoVO> listSend(MemoVO memoVO) throws Exception {
		try {
			return memoMapper.listSend(memoVO);
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(),
					new String[] { e.toString(),
							this.getClass().getSimpleName() }, e);
		}
	}

	public int listSendTotal(MemoVO memoVO) throws Exception {
		try {
			return memoMapper.listSendTotal(memoVO);
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(),
					new String[] { e.toString(),
							this.getClass().getSimpleName() }, e);
		}
	}

	@Override
	public List<MemoVO> listRecv(MemoVO memoVO) throws Exception {
		try {
			return memoMapper.listRecv(memoVO);
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(),
					new String[] { e.toString(),
							this.getClass().getSimpleName() }, e);
		}
	}

	@Override
	public int listRecvTotal(MemoVO memoVO) throws Exception {
		try {
			return memoMapper.listRecvTotal(memoVO);
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(),
					new String[] { e.toString(),
							this.getClass().getSimpleName() }, e);
		}
	}

	@Override
	public void insertMemo(MemoVO memoVO) throws Exception {
		try {
			memoMapper.insertMemoDpch(memoVO);
			
			for(MemoReceiverVO memoReceiverVO : memoVO.getRecvrInfo()){
				memoReceiverVO.setAdsrId(memoVO.getAdsrId());
				memoReceiverVO.setAdsrSeq(memoVO.getAdsrSeq());
				memoReceiverVO.setRecvrId(memoReceiverVO.getRecvrId());
				memoReceiverVO.setRecvDeptCode(memoReceiverVO.getRecvDeptCode());
				memoReceiverVO.setRegrId(memoVO.getRegrId());
				
				memoMapper.insertMemoRecv(memoReceiverVO);
			}
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(),
					new String[] { e.toString(),
							this.getClass().getSimpleName() }, e);
		}

	}
	
	public MemoReceiverVO getRecv(MemoReceiverVO memoVO) throws Exception{
		try {
			return memoMapper.getRecv(memoVO);
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(),
					new String[] { e.toString(),
				this.getClass().getSimpleName() }, e);
		}		
	}
	
	@Override
	public void insertReplyMemo(MemoVO memoVO, MemoReceiverVO memoReceiverVO) throws Exception {
		try {
			memoMapper.insertMemoDpch(memoVO);
			
			for(MemoReceiverVO rvo : memoVO.getRecvrInfo()){
				rvo.setAdsrId(memoVO.getAdsrId());
				rvo.setAdsrSeq(memoVO.getAdsrSeq());
				rvo.setRegrId(memoVO.getRegrId());
				
				memoMapper.insertMemoRecv(rvo);
				
				// ---------- 중복 답장 막기 위해 발신순번 update 하는 부분 -----------
				rvo.setAdsrId(memoReceiverVO.getAdsrId());
				rvo.setAdsrSeq(memoReceiverVO.getAdsrSeq());
				rvo.setRecvSeq(memoReceiverVO.getRecvSeq());
				
				MemoReceiverVO replyRvo = memoMapper.getRecv(rvo);
				if("DEPT".equals(replyRvo.getRecvrId())){
					//수신사용자에 발신순번 update.
					rvo.setRecvSeq(replyRvo.getAnsRecvSeq());
					rvo.setAnsAdsrSeq(memoVO.getAdsrSeq());
					memoMapper.updateAnsSeqMemoRecv(rvo);
				}else{
					rvo.setAnsAdsrSeq(memoVO.getAdsrSeq());
					memoMapper.updateAnsSeqMemoRecv(rvo);
				}
				// ---------- 중복 답장 막기 위해 발신순번 update 하는 부분 -----------
			}
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(),
					new String[] { e.toString(),
				this.getClass().getSimpleName() }, e);
		}
		
	}

	@Override
	public List<MemoReceiverVO> listRecvForSend(MemoVO memoVO) throws Exception {
		try {
			//발송자에 대한 수신목록
			List<MemoReceiverVO> listRecvForSend = memoMapper.listRecvForSend(memoVO);
			return listRecvForSend;
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(),
					new String[] { e.toString(),
							this.getClass().getSimpleName() }, e);
		}
	}
	
	@Override
	public void updateMemoRecv(MemoReceiverVO memoVO) throws Exception {
		try {
			MemoReceiverVO rvo = memoMapper.getRecv(memoVO);
			
			//부서(각각, 전체)에 대한 읽음처리시는 신규 Insert.
			if("DEPT".equals(rvo.getRecvrId())){
				if(rvo.getAnsRecvSeq() == null){ //이미 읽은건은 제외
					rvo.setAdsrId(memoVO.getAdsrId());
					rvo.setAdsrSeq(memoVO.getAdsrSeq());
					rvo.setRegrId(memoVO.getRegrId());
					rvo.setRecvrId(memoVO.getRegrId());
					rvo.setDeptRecvSeq(memoVO.getRecvSeq()); //부서의 원 수신SEQ
					rvo.setCnfmDttm(CommUtil.getDateString("yyyy-MM-dd HH:mm:ss"));
					
					memoMapper.insertMemoRecv(rvo);
				}
			}else{
				//사용자에 대한 읽음처리
				//확인일시 update.
				rvo.setRegrId(memoVO.getRegrId());
				memoMapper.updateMemoRecv(rvo);
			}
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(),
					new String[] { e.toString(),
							this.getClass().getSimpleName() }, e);
		}

	}	
	
	
	
	public int getMemoRecvCount(String userId, String deptCode) throws Exception{
		try {
			//수신건수
			MemoVO memoVO = new MemoVO();
			memoVO.setRecvrId(userId);
			memoVO.setRecvDeptCode(deptCode);
			return memoMapper.getMemoRecvCount(memoVO);
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(),
					new String[] { e.toString(),
							this.getClass().getSimpleName() }, e);
		}
	}

	@Override
	public void sendMemoByUser(String adsrId, String adsrCtt, List<String> recvrId) throws Exception {
		try {
			if(CommUtil.isEmpty(adsrId) || CommUtil.isEmpty(adsrCtt) || recvrId == null || recvrId.size() == 0){
				return;
			}
			MemoVO memoVO = new MemoVO();
			memoVO.setAdsrId(adsrId);
			if(adsrCtt.length() > 100){
				memoVO.setAdsrCtt(adsrCtt.substring(0, 100));
			}else{
				memoVO.setAdsrCtt(adsrCtt);
			}
			memoVO.setRegrId(adsrId);
			memoMapper.insertMemoDpch(memoVO); //발신
			
			MemoReceiverVO memoReceiverVO = null;
			for(String id : recvrId){
				memoReceiverVO = new MemoReceiverVO();
				memoReceiverVO.setAdsrId(memoVO.getAdsrId());
				memoReceiverVO.setAdsrSeq(memoVO.getAdsrSeq());
				memoReceiverVO.setRecvrId(id);
				memoReceiverVO.setRegrId(memoVO.getRegrId());
				
				memoMapper.insertMemoRecv(memoReceiverVO);
			}
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(), new String[] { e.toString(), this.getClass().getSimpleName() }, e);
		}
	}

	@Override
	public void sendMemoByDept(String adsrId, String adsrCtt, List<String> recvDeptCode) throws Exception {
		try {
			if(CommUtil.isEmpty(adsrId) || CommUtil.isEmpty(adsrCtt) || recvDeptCode == null || recvDeptCode.size() == 0){
				return;
			}
			MemoVO memoVO = new MemoVO();
			memoVO.setAdsrId(adsrId);
			if(adsrCtt.length() > 100){
				memoVO.setAdsrCtt(adsrCtt.substring(0, 100));
			}else{
				memoVO.setAdsrCtt(adsrCtt);
			}
			memoVO.setRegrId(adsrId);
			memoMapper.insertMemoDpch(memoVO); //발신
			
			MemoReceiverVO memoReceiverVO = null;
			for(String deptCode : recvDeptCode){
				memoReceiverVO = new MemoReceiverVO();
				memoReceiverVO.setAdsrId(memoVO.getAdsrId());
				memoReceiverVO.setAdsrSeq(memoVO.getAdsrSeq());
				memoReceiverVO.setRecvrId("DEPT");
				memoReceiverVO.setRecvDeptCode(deptCode);
				memoReceiverVO.setRegrId(memoVO.getRegrId());
				
				memoMapper.insertMemoRecv(memoReceiverVO);
			}
		} catch (Exception e) {
			throw processException(Constant.E000001.getVal(), new String[] { e.toString(), this.getClass().getSimpleName() }, e);
		}
	}
}

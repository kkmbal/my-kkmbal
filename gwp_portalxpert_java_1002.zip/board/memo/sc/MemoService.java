/**
 * 
 */
package portalxpert.board.memo.sc;

import java.util.List;
//import portalxpert.board.memo.vo.MemoVO;





import portalxpert.board.memo.vo.MemoReceiverVO;
import portalxpert.board.memo.vo.MemoVO;


/**
 * <pre>
 * 쪽지 서비스 인터페이스
 * </pre>
 * portalxpert.board.memo.sc
 * MemoService.java
 * @author 안근창
 * @since 2014. 9. 5.
 * 
 */
public interface MemoService {

	//발송목록
	public List<MemoVO> listSend(MemoVO memoVO) throws Exception;
	
	//발송목록카운트
	public int listSendTotal(MemoVO memoVO) throws Exception;
	
	//수신목록
	public List<MemoVO> listRecv(MemoVO memoVO) throws Exception;
	
	//수신목록카운트
	public int listRecvTotal(MemoVO memoVO) throws Exception;

	//메모발송
	public void insertMemo(MemoVO memoVO) throws Exception;
	
	//수신조회
	public MemoReceiverVO getRecv(MemoReceiverVO memoVO) throws Exception;
	
	//답장발송
	public void insertReplyMemo(MemoVO memoVO, MemoReceiverVO memoReceiverVO) throws Exception;

	//발신자별 수신목록
	public List<MemoReceiverVO> listRecvForSend(MemoVO memoVO) throws Exception;

	//메모 읽음처리
	public void updateMemoRecv(MemoReceiverVO memoVO) throws Exception;
	
	/**
	 * 메모 미확인 건수
	 *
	 * @param userId : 사용자ID
	 * @param deptCode : 기관코드
	 * @return
	 * @throws Exception
	 */
	public int getMemoRecvCount(String userId, String deptCode) throws Exception;
	
	/**
	 * 사용자에게 메모 발송 공개 API
	 *
	 * @param adsrId : 발신자ID
	 * @param adsrCtt : 발신내용
	 * @param List<String> recvrId : 수신자ID
	 * @return
	 * @throws Exception
	 */
	public void sendMemoByUser(String adsrId, String adsrCtt, List<String> recvrId) throws Exception;
	
	/**
	 * 부서에게 메모 발송 공개 API
	 *
	 * @param adsrId : 발신자ID
	 * @param adsrCtt : 발신내용
	 * @param List<String> recvDeptCode : 수신부서코드
	 * @return
	 * @throws Exception
	 */
	public void sendMemoByDept(String adsrId, String adsrCtt, List<String> recvDeptCode) throws Exception;
}

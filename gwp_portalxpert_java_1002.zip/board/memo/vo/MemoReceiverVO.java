package portalxpert.board.memo.vo;


/**
 * <pre>
 * 수신자 정보 VO
 * </pre>
 * portalxpert.board.memo.vo
 * MemoReceiverVO.java
 * @author 안근창
 * @since 2014. 9. 5.
 * 
 */
public class MemoReceiverVO {
	
	private String  adsrId;
	private String  adsrNm;
	private String  adsrSeq;
	private	String	recvSeq;			//수신순번
	private	String	recvrId;			//수신자id
	private	String	recvrNm;			//수신자
	private	String	recvDeptCode;		//수신부서코드
	private	String	recvDeptNm;		//수신부서
	private	String	cnfmDttm;			//확인일시
	private String  ansAdsrSeq;     //답장발신순번
	private String  deptRecvSeq;    //부서수신순번
	private String  regrId;
	private String  updrId;
	private String ansRecvSeq; //답장용 수신순번
	private int ansCnt; //답장발송순번건수
	private int seq;
	
	
	public int getAnsCnt() {
		return ansCnt;
	}

	public void setAnsCnt(int ansCnt) {
		this.ansCnt = ansCnt;
	}

	public String getAnsAdsrSeq() {
		return ansAdsrSeq;
	}

	public void setAnsAdsrSeq(String ansAdsrSeq) {
		this.ansAdsrSeq = ansAdsrSeq;
	}

	public String getDeptRecvSeq() {
		return deptRecvSeq;
	}

	public void setDeptRecvSeq(String deptRecvSeq) {
		this.deptRecvSeq = deptRecvSeq;
	}

	public String getAnsRecvSeq() {
		return ansRecvSeq;
	}

	public void setAnsRecvSeq(String ansRecvSeq) {
		this.ansRecvSeq = ansRecvSeq;
	}

	public String getAdsrNm() {
		return adsrNm;
	}

	public void setAdsrNm(String adsrNm) {
		this.adsrNm = adsrNm;
	}

	public String getRecvrNm() {
		return recvrNm;
	}

	public void setRecvrNm(String recvrNm) {
		this.recvrNm = recvrNm;
	}

	public String getRecvDeptNm() {
		return recvDeptNm;
	}

	public void setRecvDeptNm(String recvDeptNm) {
		this.recvDeptNm = recvDeptNm;
	}

	public String getRegrId() {
		return regrId;
	}

	public void setRegrId(String regrId) {
		this.regrId = regrId;
	}

	public String getUpdrId() {
		return updrId;
	}

	public void setUpdrId(String updrId) {
		this.updrId = updrId;
	}

	public int getSeq() {
		return seq;
	}
	
	public String getAdsrId() {
		return adsrId;
	}

	public void setAdsrId(String adsrId) {
		this.adsrId = adsrId;
	}

	public String getAdsrSeq() {
		return adsrSeq;
	}

	public void setAdsrSeq(String adsrSeq) {
		this.adsrSeq = adsrSeq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getRecvSeq() {
		return recvSeq;
	}
	public void setRecvSeq(String recvSeq) {
		this.recvSeq = recvSeq;
	}
	public String getRecvrId() {
		return recvrId;
	}
	public void setRecvrId(String recvrId) {
		this.recvrId = recvrId;
	}
	public String getRecvDeptCode() {
		return recvDeptCode;
	}
	public void setRecvDeptCode(String recvDeptCode) {
		this.recvDeptCode = recvDeptCode;
	}
	public String getCnfmDttm() {
		return cnfmDttm;
	}
	public void setCnfmDttm(String cnfmDttm) {
		this.cnfmDttm = cnfmDttm;
	}
}

package portalxpert.board.memo.vo;
import java.util.List;

import portalxpert.common.vo.SearchConditionVO;



/**
 * <pre>
 * 메모VO
 * </pre>
 * portalxpert.board.memo.vo
 * MemoVO.java
 * @author 안근창
 * @since 2014. 9. 5.
 * 
 */
public class MemoVO  extends SearchConditionVO{
	
	private String	adsrId;							//발신자ID
	private String	adsrNm;							//발신자
	private	String	recvrId;			//수신자id
	private	String	recvrNm;			//수신자
	private String	adsrDttm;						//발신일시
	private String	adsrCtt;						//메모내용
	private String	adsrSeq;						//시퀀스
	private String	recvSeq;						//시퀀스
	private List<MemoReceiverVO> recvrInfo;	//수신자정보VO(id,수신시간)의 리스트
	private String recvDeptCode;
	private String recvDeptNm;
	private String regrId;
	private String updrId;
	private int seq;
	
	
	public String getAdsrNm() {
		return adsrNm;
	}

	public void setAdsrNm(String adsrNm) {
		this.adsrNm = adsrNm;
	}

	public String getRecvrNm() {
		return recvrNm;
	}

	public void setRecvrNm(String recvrNm) {
		this.recvrNm = recvrNm;
	}

	public String getRecvDeptNm() {
		return recvDeptNm;
	}

	public void setRecvDeptNm(String recvDeptNm) {
		this.recvDeptNm = recvDeptNm;
	}

	public String getRecvDeptCode() {
		return recvDeptCode;
	}

	public void setRecvDeptCode(String recvDeptCode) {
		this.recvDeptCode = recvDeptCode;
	}

	public String getRegrId() {
		return regrId;
	}

	public void setRegrId(String regrId) {
		this.regrId = regrId;
	}

	public String getUpdrId() {
		return updrId;
	}

	public void setUpdrId(String updrId) {
		this.updrId = updrId;
	}

	public int getSeq() {
		return seq;
	}
	
	public String getRecvSeq() {
		return recvSeq;
	}

	public void setRecvSeq(String recvSeq) {
		this.recvSeq = recvSeq;
	}

	public String getRecvrId() {
		return recvrId;
	}

	public void setRecvrId(String recvrId) {
		this.recvrId = recvrId;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getAdsrId() {
		return adsrId;
	}
	public void setAdsrId(String adsrId) {
		this.adsrId = adsrId;
	}
	public String getAdsrDttm() {
		return adsrDttm;
	}
	public void setAdsrDttm(String adsrDttm) {
		this.adsrDttm = adsrDttm;
	}
	public String getAdsrCtt() {
		return adsrCtt;
	}
	public void setAdsrCtt(String adsrCtt) {
		this.adsrCtt = adsrCtt;
	}
	public List<MemoReceiverVO> getRecvrInfo() {
		return recvrInfo;
	}
	public void setRecvrInfo(List<MemoReceiverVO> recvrInfo) {
		this.recvrInfo = recvrInfo;
	}
	public String getAdsrSeq() {
		return adsrSeq;
	}
	public void setAdsrSeq(String adsrSeq) {
		this.adsrSeq = adsrSeq;
	}
}

/**
 * 
 */
package portalxpert.board.memo.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import portalxpert.board.memo.sc.MemoService;
import portalxpert.board.memo.vo.MemoReceiverVO;
import portalxpert.board.memo.vo.MemoVO;
import portalxpert.common.vo.JSONResult;
import portalxpert.common.vo.UserInfoVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;


/**
 * <pre>
 *메모 컨트롤러 
 * </pre>
 * portalxpert.board.memo.web
 * MemoController.java
 * @author crossent
 * @since 2014. 9. 5.
 * 
 */
@Controller
@RequestMapping("portalxpert/board/memo")
public class MemoController {

	@Resource(name = "memoService")
    private MemoService memoService;
    
	@Resource(name="messageSourceAccessor")
	private MessageSourceAccessor messageSource;
	
    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /**
     * 쪽지발송 목록조회
     *
     * @param modelMap
     * @param memoVO
     * @param pageIndex
     * @param pageUnit
     * @param req
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping("sendMemoList")
    public String getSendMemo(ModelMap modelMap,
    		@ModelAttribute("memoVO") MemoVO memoVO,
    		@RequestParam(value="pageIndex",required = false, defaultValue="1") String pageIndex,
 			@RequestParam(value="pageUnit",required = false, defaultValue="10") String pageUnit,
 			HttpServletRequest req,
 			HttpSession session) throws Exception{
    	
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo"); 
		
		memoVO.setAdsrId(info.getId());
		
		/** PropertyService.sample */
		memoVO.setPageUnit(memoVO.getPageUnit());
		memoVO.setPageSize(propertiesService.getInt("pageSize"));
		memoVO.setPageIndex(Integer.parseInt(pageIndex));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
    	paginationInfo.setCurrentPageNo(Integer.parseInt(pageIndex));
    	paginationInfo.setRecordCountPerPage(Integer.parseInt(pageUnit));
    	paginationInfo.setPageSize(memoVO.getPageSize());
    	
    	memoVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
    	memoVO.setLastIndex(paginationInfo.getLastRecordIndex());
    	memoVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
    	List<MemoVO> listSend = memoService.listSend(memoVO);
    	int totCntSendList = memoService.listSendTotal(memoVO);
    	
    	paginationInfo.setTotalRecordCount(totCntSendList);
    	
		modelMap.put("pageIndex", pageIndex);
		modelMap.put("pageUnit", pageUnit);
		modelMap.put("memoSendList", listSend);
		modelMap.put("paginationInfo", paginationInfo);
		
		//발송건에 대한 수신목록
		List<MemoReceiverVO> privRecvList = null;
    	List<MemoReceiverVO> listRecv = memoService.listRecvForSend(memoVO);
    	for(MemoVO vo : listSend){
    		privRecvList = new ArrayList<MemoReceiverVO>();
    		for(MemoReceiverVO rvo : listRecv){
    			if(vo.getAdsrId().equals(rvo.getAdsrId()) && vo.getAdsrSeq().equals(rvo.getAdsrSeq())){
    				MemoReceiverVO mvo = new MemoReceiverVO();
    				mvo.setAdsrId(rvo.getAdsrId());
    				mvo.setAdsrSeq(rvo.getAdsrSeq());
    				mvo.setRecvrId(rvo.getRecvrId());
    				mvo.setRecvrNm(rvo.getRecvrNm());
    				mvo.setRecvSeq(rvo.getRecvSeq());
    				mvo.setCnfmDttm(rvo.getCnfmDttm());
    				mvo.setRecvDeptCode(rvo.getRecvDeptCode());
    				mvo.setRecvDeptNm(rvo.getRecvDeptNm());
    				privRecvList.add(mvo);
    			}
    		}
    		vo.setRecvrInfo(privRecvList);
    	}
    	
    	modelMap.put("memoVO", memoVO);
		modelMap.put("memoRecvList", listRecv);
		
		return "/portalxpert/board/sendMemoList";
    }
    
    /**
     * 쪽지수신 목록조회
     *
     * @param modelMap
     * @param memoVO
     * @param pageIndex
     * @param pageUnit
     * @param req
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping("recvMemoList")
    public String getRecvMemo(ModelMap modelMap,
    		@ModelAttribute("memoVO") MemoVO memoVO,
    		@RequestParam(value="pageIndex",required = false, defaultValue="1") String pageIndex,
    		@RequestParam(value="pageUnit",required = false, defaultValue="10") String pageUnit,
    		HttpServletRequest req,
    		HttpSession session) throws Exception{
    	
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo"); 
    	
    	memoVO.setAdsrId(info.getId());
    	memoVO.setRecvDeptCode(info.getDeptCode());
    	
    	/** PropertyService.sample */
    	memoVO.setPageUnit(memoVO.getPageUnit());
    	memoVO.setPageSize(propertiesService.getInt("pageSize"));
    	memoVO.setPageIndex(Integer.parseInt(pageIndex));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
    	paginationInfo.setCurrentPageNo(Integer.parseInt(pageIndex));
    	paginationInfo.setRecordCountPerPage(Integer.parseInt(pageUnit));
    	paginationInfo.setPageSize(memoVO.getPageSize());
    	
    	memoVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
    	memoVO.setLastIndex(paginationInfo.getLastRecordIndex());
    	memoVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
    	
    	List<MemoVO> listRecv = memoService.listRecv(memoVO);
    	int totcntRecvList = memoService.listRecvTotal(memoVO);
    	
    	paginationInfo.setTotalRecordCount(totcntRecvList);
    	
    	modelMap.put("memoVO", memoVO);
    	modelMap.put("pageIndex", pageIndex);
    	modelMap.put("pageUnit", pageUnit);
    	modelMap.put("paginationInfo", paginationInfo);
    	modelMap.put("memoRecvList", listRecv);
    	
    	return "/portalxpert/board/recvMemoList";
    }
    
    
    /**
     * 메모발송
     *
     * @param modelMap
     * @param data
     * @param req
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "sendMemo")
    @ResponseBody
	public ModelMap sendMemo(
			ModelMap modelMap,
			@RequestParam(value = "data", required = true) String data,
			HttpServletRequest req,
			HttpSession session) throws Exception {
			
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
	  	JSONResult jsonResult = new JSONResult();
		
		try {
			JSONObject obj = JSONObject.fromObject(data);
			JSONArray recvArr = (JSONArray)obj.get("recvrInfo");
			MemoVO memoVO = new MemoVO();
			ArrayList<MemoReceiverVO> memoReceiverArr = new ArrayList<MemoReceiverVO>();
			
			
			memoVO.setAdsrId(info.getId());
			memoVO.setAdsrCtt(obj.getString("adsrCtt"));
			
			for (int i=0; i < recvArr.size(); i++){
				JSONObject objRecv = (JSONObject)recvArr.get(i);
				MemoReceiverVO memoReceiverVO = new MemoReceiverVO();
				
				memoReceiverVO.setRecvrId(objRecv.getString("recvrId"));
				memoReceiverVO.setRecvDeptCode(objRecv.getString("recvDeptCode"));
				
				memoReceiverArr.add(i, memoReceiverVO);
			}
			memoVO.setRecvrInfo(memoReceiverArr);
			memoVO.setRegrId(info.getId());
		

			memoService.insertMemo(memoVO);

			
			jsonResult.setMessage("발송했습니다."); 
		} catch (Exception e) {
			jsonResult.setSuccess(false);
			jsonResult.setMessage(messageSource.getMessage("common.error")); 
 			jsonResult.setErrMessage(e.getMessage());
		}
		
		modelMap.put("jsonResult", jsonResult);
		return modelMap;
	}
    
    /**
     * 메모 답장
     * 
     * @param modelMap
     * @param data
     * @param req
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "sendReplyMemo")
    @ResponseBody
    public ModelMap sendReplyMemo(
    		ModelMap modelMap,
    		@RequestParam(value = "data", required = true) String data,
    		HttpServletRequest req,
    		HttpSession session) throws Exception {
    	
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
    	JSONResult jsonResult = new JSONResult();
    	
    	JSONObject obj = JSONObject.fromObject(data);
    	JSONArray recvArr = (JSONArray)obj.get("recvrInfo");
    	MemoVO memoVO = new MemoVO();
    	memoVO.setAdsrId(info.getId());
    	memoVO.setAdsrCtt(obj.getString("adsrCtt"));
    	
    	boolean enableReply = false;
    	
    	try {
    		MemoReceiverVO rvo = new MemoReceiverVO();
    		rvo.setAdsrId(obj.getString("adsrId"));
    		rvo.setAdsrSeq(obj.getString("adsrSeq"));
    		rvo.setRecvSeq(obj.getString("recvSeq"));
    		rvo.setRegrId(info.getId());
	    	MemoReceiverVO replyMemo = memoService.getRecv(rvo); //수신조회.
	    	if(replyMemo != null){
				if("DEPT".equals(replyMemo.getRecvrId())){
					if(replyMemo.getAnsCnt() == 0){ //ANS_ADSR_SEQ 건.
						enableReply = true;
					}
				}else{
					if(replyMemo.getAnsAdsrSeq() == null){
						enableReply = true;
					}
				}	    		
	    		
	    		
	    	}
	    	if(enableReply){
		    	ArrayList<MemoReceiverVO> memoReceiverArr = new ArrayList<MemoReceiverVO>();
		    	for (int i=0; i < recvArr.size(); i++){
		    		JSONObject objRecv = (JSONObject)recvArr.get(i);
		    		MemoReceiverVO memoReceiverVO = new MemoReceiverVO();
		    		
		    		memoReceiverVO.setRecvrId(objRecv.getString("recvrId"));
		    		memoReceiverVO.setRecvDeptCode(objRecv.getString("recvDeptCode"));
		    		
		    		memoReceiverArr.add(i, memoReceiverVO);
		    	}
		    	memoVO.setRecvrInfo(memoReceiverArr);
		    	memoVO.setRegrId(info.getId());
	
	    		memoService.insertReplyMemo(memoVO, rvo);
	    		
	    		
	    		jsonResult.setMessage("발송했습니다."); 
	    	}else{
	    		jsonResult.setMessage("이미 발송했습니다."); 
	    	}
    	} catch (Exception e) {
    		jsonResult.setSuccess(false);
    		jsonResult.setMessage(messageSource.getMessage("common.error")); 
    		jsonResult.setErrMessage(e.getMessage());
    	}
    	
    	modelMap.put("jsonResult", jsonResult);
    	return modelMap;
    }
    
    /**
     * 메모 읽음처리
     *
     * @param modelMap
     * @param data
     * @param req
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "updateMemo")
    @ResponseBody
    public ModelMap updateMemo(
    		ModelMap modelMap,
    		@RequestParam(value = "data", required = true) String data,
    		HttpServletRequest req,
    		HttpSession session) throws Exception {
    	
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
    	JSONResult jsonResult = new JSONResult();
    	
    	try {
	    	JSONObject obj = JSONObject.fromObject(data);
	    	MemoReceiverVO memoReceiverVO = new MemoReceiverVO();
	    	memoReceiverVO.setAdsrId(obj.getString("adsrId"));
	    	memoReceiverVO.setAdsrSeq(obj.getString("adsrSeq"));
	    	memoReceiverVO.setRecvSeq(obj.getString("recvSeq"));
	    	memoReceiverVO.setRegrId(info.getId());
	    	memoReceiverVO.setRecvDeptCode(info.getDeptCode());
    	
    		memoService.updateMemoRecv(memoReceiverVO);
    		
    	} catch (Exception e) {
    		jsonResult.setSuccess(false);
    		jsonResult.setMessage(messageSource.getMessage("common.error")); 
    		jsonResult.setErrMessage(e.getMessage());
    	}
    	
    	modelMap.put("jsonResult", jsonResult);
    	return modelMap;
    }
 
}

package portalxpert.board.memo.mapper;

import java.util.List;

import portalxpert.board.memo.vo.MemoReceiverVO;
import portalxpert.board.memo.vo.MemoVO;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("memoMapper")
public interface MemoMapper {
	
	public List<MemoVO> listSend(MemoVO memoVO);
	
	public int listSendTotal(MemoVO memoVO);
	
	public List<MemoVO> listRecv(MemoVO memoVO);
	
	public int listRecvTotal(MemoVO memoVO);
	
	public int insertMemoDpch(MemoVO memoVO);
	
	public void insertMemoRecv(MemoReceiverVO memoVO);

	public List<MemoReceiverVO> listRecvForSend(MemoVO memoVO);

	public void updateMemoRecv(MemoReceiverVO memoVO);
	
	public void updateAnsSeqMemoRecv(MemoReceiverVO memoVO);

	public MemoReceiverVO getRecv(MemoReceiverVO memoVO);

	public int getMemoRecvCount(MemoVO memoVO);

	
}

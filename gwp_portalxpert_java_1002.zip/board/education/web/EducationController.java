package portalxpert.board.education.web;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import portalxpert.board.board100.vo.BbsEdcReqInfoVO;
import portalxpert.board.board100.vo.BbsEdcTgtInfoVO;
import portalxpert.board.board100.vo.BbsNotiAddItemInfoVO;
import portalxpert.board.board100.vo.BbsNotiInfoVO;
import portalxpert.board.board210.sc.Board210Service;
import portalxpert.board.education.sc.EducationService;
import portalxpert.board.memo.sc.MemoService;
import portalxpert.common.utils.CommUtil;
import portalxpert.common.utils.JSONUtils;
import portalxpert.common.vo.BoardSearchVO;
import portalxpert.common.vo.JSONResult;
import portalxpert.common.vo.UserInfoVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
@RequestMapping("portalxpert/board210")
public class EducationController {
    
	private final Logger logger = LoggerFactory.getLogger(EducationController.class); 
   
    @Resource(name = "educationService")
    private EducationService educationService;
    
    @Resource(name = "board210Service")
    private Board210Service board210Service;
    
    @Resource(name = "memoService")
    private MemoService memoService;   
    
    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    @Resource(name="messageSourceAccessor")
    private MessageSourceAccessor messageSource;
    
   
    /**
     * 교육신청 목록 (동일부서, 동일날짜)
     * @param 
     * @return ModelMap
     * @exception Exception
     * @auther crossent 
     */
    @RequestMapping(value="/bbsEdcReqDeptEqualList" )
    public ModelMap bbsEdcReqDeptEqualList(
 			ModelMap modelMap,
 			@RequestParam(value="notiId",required = true) String notiId,
 			@RequestParam(value="deptCode",required = true) String deptCode,
 			@RequestParam(value="edcDttm",required = false) String edcDttm,
 			HttpSession session
 			)
            throws Exception {
    	
    	JSONResult jsonResult = new JSONResult();
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
		try{	
			BbsEdcReqInfoVO reqInfo = new BbsEdcReqInfoVO();
			reqInfo.setNotiId(notiId);
			reqInfo.setDeptCode(deptCode);
			reqInfo.setEdcDttm(edcDttm);
			
			List<BbsEdcReqInfoVO> reqInfoList = educationService.getEdcReqDeptInfoList(reqInfo); //교육신청정보
			
			modelMap.put("reqInfoList", JSONUtils.objectToJSON(reqInfoList));
			jsonResult.setSuccess(true);
			jsonResult.setMessage("");
			
		}catch(Exception e){
			jsonResult.setSuccess(false);
			jsonResult.setMessage(messageSource.getMessage("common.error")); 
 			jsonResult.setErrMessage(e.getMessage());
		}	
    	
		modelMap.put("jsonResult", jsonResult);
		
		return modelMap;
    }    
    
    /**
     * 교육신청 목록 팝업 
     * @param 
     * @return ModelMap
     * @exception Exception
     * @auther crossent 
     */
    @RequestMapping(value="/bbsEdcReqListPop" )
    public String bbsEdcReqListPop(
    		ModelMap modelMap,
    		@RequestParam(value="notiId",required = true) String notiId,
    		@RequestParam(value="deptCode",required = true) String deptCode,
    		@RequestParam(value="edcDttm",required = false) String edcDttm,
    		HttpSession session
    		)
    				throws Exception {
    	
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
		BbsEdcReqInfoVO reqInfo = new BbsEdcReqInfoVO();
		reqInfo.setNotiId(notiId);
		reqInfo.setDeptCode(deptCode);
		reqInfo.setEdcDttm(edcDttm);
		
		List<BbsEdcReqInfoVO> reqInfoList = educationService.getEdcReqDeptInfoList(reqInfo); //교육신청정보
		
		modelMap.put("reqInfoList", reqInfoList);
    	
    	return "/portalxpert/board/edcReqListPop";
    }    
    
    /**
     * 교육신청 팝업
     * @param 
     * @return String
     * @exception Exception
     * @auther crossent 
     */
    @RequestMapping(value="/bbsEdcReqInfoPop" )
    public String bbsEdcReqInfoPop(
 			ModelMap modelMap,
 			@RequestParam(value="notiId",required = true) String notiId,
 			@RequestParam(value="reqSeq",required = false) String reqSeq,
 			HttpSession session
 			) throws Exception {
    	
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
    	String data = "{\"notiId\":\""+notiId+"\"}";
    	List notiInfo = board210Service.getBbsNotiInfoView(data);
    	
    	BbsNotiInfoVO vo = null;
    	String edcCnt = null;
    	String edcType = null;
    	if(notiInfo.size() > 0){
    		vo = (BbsNotiInfoVO)(notiInfo.get(0));
    		modelMap.put("notiInfo", vo);
    		
			List<BbsNotiAddItemInfoVO> addItemInfoList = board210Service.getNotiAddItemList(vo);
			for(BbsNotiAddItemInfoVO addVO : addItemInfoList){
				if("EDC_TYPE".equals(addVO.getNotiItem())){ //교육유형
					modelMap.put("edcType", addVO.getNotiItemVal());
					edcType = addVO.getNotiItemVal();
				}
				if("EDC_CNT".equals(addVO.getNotiItem())){ //교육인원
					modelMap.put("edcCnt", addVO.getNotiItemVal());
					edcCnt = addVO.getNotiItemVal();
				}
				if("EDC_TIME_DIV".equals(addVO.getNotiItem())){ //교육횟수
					modelMap.put("edcTimeDiv", addVO.getNotiItemVal());
				}
				
			}
			
			if(!CommUtil.isEmpty(reqSeq)){
				BbsEdcReqInfoVO reqInfoVo = new BbsEdcReqInfoVO();
				reqInfoVo.setNotiId(vo.getNotiId());
				reqInfoVo.setReqSeq(reqSeq);
				reqInfoVo.setRegrId(info.getId());
			
				BbsEdcReqInfoVO reqInfo = educationService.getEdcReqInfo(reqInfoVo); //교육신청정보
				List<BbsEdcTgtInfoVO> tgtInfoList = educationService.getEdcTgtInfoList(reqInfo); //교육대상정보
				
				
				modelMap.put("tgtInfo", tgtInfoList);
				if(reqInfo != null){
					modelMap.put("reqInfo", reqInfo);
					
					if("020".equals(edcType)){ //방문교육
						BbsEdcReqInfoVO timeVO = new BbsEdcReqInfoVO();
						timeVO.setNotiId(notiId);
						timeVO.setDeptCode(reqInfo.getDeptCode());
						timeVO.setEdcDttm(reqInfo.getEdcDttm());
						List<BbsEdcReqInfoVO> timeList = educationService.getEdcReqDeptInfoList(reqInfo);
						if(timeList.size() > 0){
							if(timeList.size() == 1){
								String timeDiv = timeList.get(0).getEdcTimeDiv();
								if("031".equals(timeDiv)){
									modelMap.put("edcTimeDiv031", "Y"); //2회 오전
								}else if("032".equals(timeDiv)){
									modelMap.put("edcTimeDiv032", "Y"); //2회 오후
								}
							}else{
								modelMap.put("edcTimeDiv030", "Y"); //2회 모두 신청중.
							}
						}
					}
				}
			}
			int reqCnt = educationService.getEdcReqCnt(vo); //신청가능인원
			modelMap.put("reqCnt", reqCnt);
			
    	}
    	
    	return "/portalxpert/board/edcReqInfoPop";
    }  
    
    /**
     * 교육신청 등록 
     * @param 
     * @return ModelMap
     * @exception Exception
     * @auther crossent 
     */
    @RequestMapping(value="/insertEdcReq" )
    public ModelMap insertEdcReq(
 			ModelMap modelMap,
 			@RequestParam(value="data" ,required = true) String data,
 			HttpSession session
 			)
            throws Exception {
    	
    	JSONResult jsonResult = new JSONResult();
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
		try{	
	    	JSONObject bbsObject = JSONObject.fromObject(data);
	    	String notiId = bbsObject.getString("notiId");
	    	String endYn = getEdcEndYn(notiId);
	    	String reqSeq = bbsObject.getString("reqSeq");
	    	
	    	
			if("Y".equals(endYn)){ //마감		
				jsonResult.setMessage(messageSource.getMessage("save.not"));
			}else{
				JSONArray jsonArr = (JSONArray)bbsObject.get("tgtInfo");
				String edcCnt = getEdcReqCnt(bbsObject.getString("notiId") ,jsonArr.size()); //신청인원마감체크
				String reqStatCode = "Y"; //정상
				if("N".equals(edcCnt)){
					reqStatCode = "W"; //대기
				}
				
				if(CommUtil.isEmpty(reqSeq)){
					//동일기관, 동일날짜, 동일시간 신청체크.
					BbsEdcReqInfoVO equalVO = educationService.getEdcReqEqualList(data);
					if(equalVO != null){
						jsonResult.setMessage(messageSource.getMessage("save.already"));
					}else{
						//추가
						educationService.insertEdcReq(data, reqStatCode, session);
						jsonResult.setMessage(messageSource.getMessage("save.ok"));
					}
				}else{
					//수정
					educationService.insertEdcReq(data, reqStatCode, session);
					jsonResult.setMessage(messageSource.getMessage("save.ok"));
				}
				
			}
			jsonResult.setSuccess(true);
			
		}catch(Exception e){
			jsonResult.setSuccess(false);
			jsonResult.setMessage(messageSource.getMessage("common.error")); 
 			jsonResult.setErrMessage(e.getMessage());
		}	
    	
		modelMap.put("jsonResult", jsonResult);
		
		return modelMap;
    }
  
    
    /**
     * 교육신청 삭제 
     * @param 
     * @return ModelMap
     * @exception Exception
     * @auther crossent 
     */
    @RequestMapping(value="/deleteEdcReq" )
    public ModelMap deleteEdcReq(
    		ModelMap modelMap,
    		@RequestParam(value="notiId" ,required = true) String notiId,
    		@RequestParam(value="reqSeq" ,required = true) String reqSeq,
    		@RequestParam(value="edcType" ,required = true) String edcType,
    		HttpSession session
    		)
    				throws Exception {
    	
    	JSONResult jsonResult = new JSONResult();
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
    	try{	
    		
    		String endYn = getEdcEndYn(notiId);
			if("Y".equals(endYn)){			
				jsonResult.setMessage(messageSource.getMessage("save.not"));
			}else{
				BbsEdcReqInfoVO vo = new BbsEdcReqInfoVO();
				vo.setNotiId(notiId);
				vo.setReqSeq(reqSeq);
				vo.setRegrId(info.getId());
				int delCnt = educationService.deleteEdcReq(vo);
				
				if(delCnt > 0 && "010".equals(edcType)){ //집합교육일 경우
					//다음선착순 대기건 승인처리
					List<BbsEdcReqInfoVO> resultList = educationService.updateEdcReqApproval(vo);
					if(resultList != null){
						List<String> recvrId = new ArrayList<String>();
						String notiTitle = "";
						for(int i=0;i<resultList.size();i++){
				    		recvrId.add(resultList.get(i).getRegrId());
				    		if(i==0) notiTitle = resultList.get(i).getNotiTitle();
						}
						//쪽지발송
						memoService.sendMemoByUser("system", "대기중인 교육("+notiTitle+")이 승인되었습니다.", recvrId);
					}
					jsonResult.setMessage(messageSource.getMessage("save.ok"));
				}
			}
    		
    		jsonResult.setSuccess(true);
    		
    	}catch(Exception e){
    		jsonResult.setSuccess(false);
    		jsonResult.setMessage(messageSource.getMessage("common.error")); 
    		jsonResult.setErrMessage(e.getMessage());
    	}	
    	
    	modelMap.put("jsonResult", jsonResult);
    	
    	return modelMap;
    }   
    
    /**
     * 교육신청 마감 
     * @param 
     * @return ModelMap
     * @exception Exception
     * @auther crossent 
     */
    @RequestMapping(value="/updateEdcReqEnd" )
    public ModelMap updateEdcReqEnd(
    		ModelMap modelMap,
    		@RequestParam(value="notiId" ,required = true) String notiId,
    		HttpSession session
    		)
    				throws Exception {
    	
    	JSONResult jsonResult = new JSONResult();
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
    	try{	
    		String endYn = getEdcEndYn(notiId);
			if("Y".equals(endYn)){			
				jsonResult.setMessage(messageSource.getMessage("save.not"));
			}else{
	    		BbsNotiAddItemInfoVO vo = new BbsNotiAddItemInfoVO();
	    		vo.setNotiId(notiId);
	    		vo.setUpdrId(info.getId());
	    		vo.setUpdrName(info.getName());
	    		educationService.updateEdcReqEnd(vo);
	    		
	    		jsonResult.setSuccess(true);
	    		jsonResult.setMessage(messageSource.getMessage("save.ok"));
			}
    		
    	}catch(Exception e){
    		jsonResult.setSuccess(false);
    		jsonResult.setMessage(messageSource.getMessage("common.error")); 
    		jsonResult.setErrMessage(e.getMessage());
    	}	
    	
    	modelMap.put("jsonResult", jsonResult);
    	
    	return modelMap;
    }  
    
    /**
     * 교육신청 반려 
     * @param 
     * @return ModelMap
     * @exception Exception
     * @auther crossent 
     */
    @RequestMapping(value="/rejectEdcReq" )
    public ModelMap rejectEdcReq(
    		ModelMap modelMap,
    		@RequestParam(value="notiId" ,required = true) String notiId,
    		@RequestParam(value="reqSeq" ,required = true) String reqSeq,
    		HttpSession session
    		)
    				throws Exception {
    	
    	JSONResult jsonResult = new JSONResult();
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
    	try{	
    		
    		String endYn = getEdcEndYn(notiId);
			if("N".equals(endYn)){			
				BbsEdcReqInfoVO vo = new BbsEdcReqInfoVO();
	    		vo.setNotiId(notiId);
	    		vo.setReqSeq(reqSeq);
	    		vo.setRegrId(info.getId());
	    		BbsEdcReqInfoVO edcReqInfo = educationService.getEdcReqInfo(vo); //교육신청정보
	    		
	    		educationService.updateEdcReq(vo); //반려
	    		
	    		//쪽지발송
	    		List<String> recvrId = new ArrayList<String>();
	    		recvrId.add(edcReqInfo.getRegrId());
	    		memoService.sendMemoByUser(info.getId(), "신청하신 교육("+edcReqInfo.getNotiTitle()+")이 반려되었습니다.", recvrId);
	    		
				jsonResult.setMessage(messageSource.getMessage("save.ok"));
			}else{
				jsonResult.setMessage(messageSource.getMessage("save.not"));
			}
    		
    		jsonResult.setSuccess(true);
    		
    	}catch(Exception e){
    		jsonResult.setSuccess(false);
    		jsonResult.setMessage(messageSource.getMessage("common.error")); 
    		jsonResult.setErrMessage(e.getMessage());
    	}	
    	
    	modelMap.put("jsonResult", jsonResult);
    	
    	return modelMap;
    }
    
    /**
     * 교육신청 관리 목록 
     * @param 
     * @return ModelMap
     * @exception Exception
     * @auther crossent 
     */
    @RequestMapping(value="/bbsEdcReqList" )
    public String bbsEdcReqList(
    		ModelMap modelMap,
    		@ModelAttribute("boardSearchVO") BoardSearchVO boardSearchVO,
    		@RequestParam(value="pageIndex",required = false, defaultValue="1") String pageIndex,
    		@RequestParam(value="pageUnit",required = false, defaultValue="10") String pageUnit,
    		@RequestParam(value="regDttmFrom",required = false) String regDttmFrom,
    		@RequestParam(value="regDttmTo",required = false) String regDttmTo,
    		@RequestParam(value="myNotiTitle",required = false) String myNotiTitle,
    		HttpSession session
    		)
    				throws Exception {
    	
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
    	/** PropertyService.sample */
		boardSearchVO.setPageUnit(Integer.parseInt(pageUnit));
		boardSearchVO.setPageSize(propertiesService.getInt("pageSize"));
		boardSearchVO.setPageIndex(Integer.parseInt(pageIndex));
		boardSearchVO.setRegDttmFrom(regDttmFrom);
		boardSearchVO.setRegDttmTo(regDttmTo);
		boardSearchVO.setMyNotiTitle(myNotiTitle);
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(boardSearchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(boardSearchVO.getPageUnit());
		paginationInfo.setPageSize(boardSearchVO.getPageSize());
		
		boardSearchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		boardSearchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		boardSearchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		List<BbsEdcReqInfoVO> reqInfoList = educationService.getEdcReqInfoManageList(boardSearchVO); //교육신청정보
		for(BbsEdcReqInfoVO reqInfo : reqInfoList){
    		if("N".equals(getEdcReqCnt(reqInfo.getNotiId(), 0))){ //인원제한마감여부
    			reqInfo.setEdcEnd("Y");
    		}
    	}
		int totCnt = educationService.getEdcReqInfoManageListTotCnt(boardSearchVO);
		
		paginationInfo.setTotalRecordCount(totCnt);
		modelMap.put("reqInfoList", reqInfoList);
		modelMap.put("pageIndex", pageIndex);
		modelMap.put("pageUnit", pageUnit);
		modelMap.put("boardSearchVO", boardSearchVO);
		modelMap.put("paginationInfo", paginationInfo);
    	
    	return "/portalxpert/board/edcReqList";
    } 
    
    /**
     * 교육신청 결과 목록 
     * @param 
     * @return ModelMap
     * @exception Exception
     * @auther crossent 
     */
    @RequestMapping(value="/bbsEdcTgtList" )
    public String bbsEdcTgtList(
    		ModelMap modelMap,
    		@ModelAttribute("boardSearchVO") BoardSearchVO boardSearchVO,
    		@RequestParam(value="pageIndex",required = false, defaultValue="1") String pageIndex,
    		@RequestParam(value="pageUnit",required = false, defaultValue="10") String pageUnit,
    		@RequestParam(value="regDttmFrom",required = false) String regDttmFrom,
    		@RequestParam(value="regDttmTo",required = false) String regDttmTo,
    		@RequestParam(value="myNotiTitle",required = false) String myNotiTitle,
    		HttpSession session
    		)
    				throws Exception {
    	
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
    	/** PropertyService.sample */
    	boardSearchVO.setPageUnit(Integer.parseInt(pageUnit));
    	boardSearchVO.setPageSize(propertiesService.getInt("pageSize"));
    	boardSearchVO.setPageIndex(Integer.parseInt(pageIndex));
    	boardSearchVO.setRegDttmFrom(regDttmFrom);
		boardSearchVO.setRegDttmTo(regDttmTo);
		boardSearchVO.setMyNotiTitle(myNotiTitle);
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
    	paginationInfo.setCurrentPageNo(boardSearchVO.getPageIndex());
    	paginationInfo.setRecordCountPerPage(boardSearchVO.getPageUnit());
    	paginationInfo.setPageSize(boardSearchVO.getPageSize());
    	
    	boardSearchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
    	boardSearchVO.setLastIndex(paginationInfo.getLastRecordIndex());
    	boardSearchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
    	
    	List<BbsEdcReqInfoVO> tgtInfoList = educationService.getEdcTgtInfoManageList(boardSearchVO); //교육신청정보
    	for(BbsEdcReqInfoVO reqInfo : tgtInfoList){
    		if("N".equals(getEdcReqCnt(reqInfo.getNotiId(), 0))){ //인원제한마감여부
    			reqInfo.setEdcEnd("Y");
    		}
    	}
    	int totCnt = educationService.getEdcTgtInfoManageListTotCnt(boardSearchVO);
    	
    	paginationInfo.setTotalRecordCount(totCnt);
    	modelMap.put("tgtInfoList", tgtInfoList);
    	modelMap.put("pageIndex", pageIndex);
    	modelMap.put("pageUnit", pageUnit);
    	modelMap.put("boardSearchVO", boardSearchVO);
    	modelMap.put("paginationInfo", paginationInfo);
    	
    	return "/portalxpert/board/edcTgtList";
    } 
    
    /**
     * 교육대상 목록 팝업 
     * @param 
     * @return ModelMap
     * @exception Exception
     * @auther crossent 
     */
    @RequestMapping(value="/bbsEdcTgtListPop" )
    public String bbsEdcTgtListPop(
    		ModelMap modelMap,
    		@RequestParam(value="notiId",required = true) String notiId,
    		@RequestParam(value="reqSeq",required = true) String reqSeq,
    		HttpSession session
    		)
    				throws Exception {
    	
    	//UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
		BbsEdcReqInfoVO reqInfo = new BbsEdcReqInfoVO();
		reqInfo.setNotiId(notiId);
		reqInfo.setReqSeq(reqSeq);
		
		BbsEdcReqInfoVO edcReqInfo = educationService.getEdcReqInfo(reqInfo); //교육신청정보
		List<BbsEdcTgtInfoVO> tgtInfoList = educationService.getEdcTgtInfoList(reqInfo); //교육대상정보
		
		modelMap.put("edcReqInfo", edcReqInfo);
		modelMap.put("tgtInfoList", tgtInfoList);
    	
    	return "/portalxpert/board/edcTgtListPop";
    }    
    
    /**
     * 교육신청 결과 목록(엑셀) 
     * @param 
     * @return ModelMap
     * @exception Exception
     * @auther crossent 
     */
    @RequestMapping(value="/bbsEdcTgtListExcel" )
    public void bbsEdcTgtListExcel(
    		ModelMap modelMap,
    		@ModelAttribute("boardSearchVO") BoardSearchVO boardSearchVO,
    		@RequestParam(value="regDttmFrom",required = false) String regDttmFrom,
    		@RequestParam(value="regDttmTo",required = false) String regDttmTo,
    		@RequestParam(value="myNotiTitle",required = false) String myNotiTitle,
    		HttpSession session,
    		HttpServletResponse response
    		)
    				throws Exception {
    	
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
    	boardSearchVO.setRegDttmFrom(regDttmFrom);
		boardSearchVO.setRegDttmTo(regDttmTo);
		boardSearchVO.setMyNotiTitle(myNotiTitle);
    	
    	List<BbsEdcReqInfoVO> tgtInfoList = educationService.getEdcTgtInfoManageListExcel(boardSearchVO); //교육신청정보
    	
    	modelMap.put("tgtInfoList", tgtInfoList);
    	
    	//Excel Write
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Sheet1");
		sheet.setDefaultColumnWidth((short)15);
		
		//Font 설정
		HSSFFont font = workbook.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		
		HSSFCellStyle titlestyle = workbook.createCellStyle();
		titlestyle.setFont(font);		
		HSSFRow row = sheet.createRow((short)0);
		HSSFCell cell1 = row.createCell((short)0);
		cell1.setEncoding(HSSFCell.ENCODING_UTF_16);
		cell1.setCellValue("교육신청결과");
		cell1.setCellStyle(titlestyle);	
		
		
		row = sheet.createRow((short)2);
		cell1 = row.createCell((short)0);
		cell1.setEncoding(HSSFCell.ENCODING_UTF_16);
		cell1.setCellValue("교육일자 : " + regDttmFrom + " ~ " + regDttmTo);
		cell1.setCellStyle(titlestyle);
		
		row = sheet.createRow((short)3);
		cell1 = row.createCell((short)0);
		cell1.setEncoding(HSSFCell.ENCODING_UTF_16);
		cell1.setCellValue("교육명 : " + myNotiTitle);
		cell1.setCellStyle(titlestyle);
		
		String[] header = {"교육일자","교육유형","구분","교육명","교육인원","명단"};
		
		row = sheet.createRow((short)5);
		for(int i=0;i<header.length;i++){
			cell1 = row.createCell((short)i);
			cell1.setEncoding(HSSFCell.ENCODING_UTF_16);
			cell1.setCellValue(header[i]);
			cell1.setCellStyle(titlestyle);
		}
		
		for(int i=0; i<tgtInfoList.size(); i++)
		{				
			BbsEdcReqInfoVO rsltVo = tgtInfoList.get(i);
			
			row = sheet.createRow((short)(i+6));
			for(int j=0;j<header.length;j++){
				cell1 = row.createCell((short)j);
				cell1.setEncoding(HSSFCell.ENCODING_UTF_16);
				if(j==0){
					cell1.setCellValue(rsltVo.getEdcDttm());
				}else if(j==1){
					if("010".equals(rsltVo.getEdcType())){
						cell1.setCellValue("집합");
					}else  if("020".equals(rsltVo.getEdcType())){
						cell1.setCellValue("방문");
					}
				}else if(j==2){
					if("010".equals(rsltVo.getEdcTimeDiv())){
						cell1.setCellValue("오전");
					}else  if("020".equals(rsltVo.getEdcTimeDiv())){
						cell1.setCellValue("오후");
					}else  if("030".equals(rsltVo.getEdcTimeDiv())){
						cell1.setCellValue("오전/오후");
					}
				}else if(j==3){
					cell1.setCellValue(rsltVo.getNotiTitle());
				}else if(j==4){
					cell1.setCellValue(rsltVo.getEdcTgtCnt());
				}else if(j==5){
					cell1.setCellValue(rsltVo.getUserName());
				}
			}
		}
			
		
		SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyyMMddHHmmss");
		String today = formatter.format(new Date());						
		String filename = "education_result_"+today+".xls";
		OutputStream out = response.getOutputStream();
		response.setCharacterEncoding("utf-8");
		response.setContentType("application/x-msexcel");
		response.setHeader("Content-Disposition", "attachment;filename="+filename);
		workbook.write(response.getOutputStream());						
		workbook.write(out);
		out.close();
    }     
    
    
    /**
     * 교육신청관리 상세보기
     * @param modelMap
     * @return board/edcReqView
     * @throws Exception
     * @auther crossent
     */
    @RequestMapping(value="/getEdcReqView")
    public String getEdcReqView(
 			ModelMap modelMap,
 			@RequestParam(value="notiId" ,required = true) String notiId,
 			@RequestParam(value="pageIndex" ,required = false) String pageIndex,
 			HttpServletRequest request,
 			HttpSession session
 			)
            throws Exception {
    	
    	UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");
    	
    	BbsNotiInfoVO notiVo = new BbsNotiInfoVO();
		notiVo.setNotiId(notiId);
		notiVo.setUserId(info.getId());
		
		BbsNotiInfoVO bbsNotiInfoViewForNotiConts = board210Service.getBbsNotiInfoViewForNotiConts(notiId);//본문가져오기 
		String notiConts = bbsNotiInfoViewForNotiConts==null?"":bbsNotiInfoViewForNotiConts.getNotiConts();
		if(notiConts != null){ 
			notiConts = notiConts.replaceAll("\r\n","<br>");
			notiConts = CommUtil.scriptRemove(notiConts);
		}else{ 
			notiConts = "";
		}
		
		String data = "{\"notiId\":\""+notiId+"\"}";
		List notiInfo = board210Service.getBbsNotiInfoView(data);
		

		BbsNotiInfoVO vo =  (BbsNotiInfoVO)notiInfo.get(0);
		
		List notiFile = board210Service.getBbsNotiApndFileListForView(data);
		
		String notiReadmanAsgnYn = "A";
		
		//달력타입(교육게시판)
		List<BbsNotiAddItemInfoVO> addItemInfoList = board210Service.getNotiAddItemList(vo);
		String edcCnt = null;
		for(BbsNotiAddItemInfoVO addVO : addItemInfoList){
			if("EDC_TYPE".equals(addVO.getNotiItem())){
				modelMap.put("edcType", addVO.getNotiItemVal());
			}
			if("EDC_CNT".equals(addVO.getNotiItem())){
				modelMap.put("edcCnt", addVO.getNotiItemVal());
				edcCnt = addVO.getNotiItemVal();
			}
			if("EDC_TIME_DIV".equals(addVO.getNotiItem())){
				modelMap.put("edcTimeDiv", addVO.getNotiItemVal());
			}
		}
		
    	String endYn = getEdcEndYn(notiId);
		if("N".equals(getEdcReqCnt(notiId, 0))){ //인원제한마감여부
			endYn = "Y";
		}
		modelMap.put("edcEndYn", endYn); //마감여부
		
		int reqCnt = educationService.getEdcReqCnt(vo); //신청가능인원
		modelMap.put("reqCnt",reqCnt);
		
		BbsEdcReqInfoVO reqVo = new BbsEdcReqInfoVO();
		reqVo.setNotiId(notiId);
		List<BbsEdcReqInfoVO> edcReqInfoList = educationService.getEdcReqInfoViewList(reqVo); //교육신청정보
		
		
		BbsEdcReqInfoVO reqInfoVo = null;
		for(BbsEdcReqInfoVO edcvo : edcReqInfoList){
			if("010".equals(edcvo.getEdcType())){ //집합
				reqInfoVo = new BbsEdcReqInfoVO();
				reqInfoVo.setNotiId(vo.getNotiId());
				reqInfoVo.setReqSeq(edcvo.getReqSeq());
				List<BbsEdcTgtInfoVO> tgtInfoList = educationService.getEdcTgtInfoList(reqInfoVo);
				
				StringBuilder sb = new StringBuilder();
				int idx = 0;
				for(BbsEdcTgtInfoVO tgtvo : tgtInfoList){
					if(idx < 3){
						sb.append(tgtvo.getUserName()).append(",");
					}else{
						break;
					}
					idx++;
				}
				edcvo.setUserName(sb.toString());
			}
		}

	
		
		modelMap.put("notiInfo", vo);
		modelMap.put("edcReqInfoList", edcReqInfoList);
		modelMap.put("notiFile", notiFile);
		modelMap.put("notiConts",notiConts );
		modelMap.put("noTagNotiConts", CommUtil.htmlEscape(notiConts) );
    	modelMap.put("notiId", notiId);
    	modelMap.put("userId", info.getId());
    	modelMap.put("pageIndex", pageIndex);
		
		return "/portalxpert/board/edcReqView";
    }    
    
    
    
    
    //교육 마감여부 체크
	private String getEdcEndYn(String notiId) throws Exception {
		BbsNotiInfoVO vo = new BbsNotiInfoVO();
		vo.setNotiId(notiId);
		vo.setNotiItem("EDC_END_YN");
		
		List<BbsNotiAddItemInfoVO> addItemInfoList = board210Service.getNotiAddItemList(vo);
		String endYn = "";
		if(addItemInfoList.size() > 0){
			endYn = addItemInfoList.get(0).getNotiItemVal();
		}
		return endYn;
	}     
    
    //교육신청가능인원수
    private String getEdcReqCnt(String notiId, int applyCnt)  throws Exception{
    	String count = "Y";
    	
    	BbsNotiInfoVO vo = new BbsNotiInfoVO();
    	vo.setNotiId(notiId);
    	
    	int reqCnt = educationService.getEdcReqCnt(vo); //신청가능인원
    	
    	reqCnt = reqCnt - applyCnt;
    	
    	vo.setNotiItem("EDC_TYPE"); //교육유형
		List<BbsNotiAddItemInfoVO> addItemInfoList = board210Service.getNotiAddItemList(vo);
		if(addItemInfoList.size() > 0){
			String edcType = addItemInfoList.get(0).getNotiItemVal();
			if("010".equals(edcType)){ //집합
				if(reqCnt > 0){
					count = "Y";
				}else{
					count = "N";
				}
			}
		}
    	
		return count;
    }    
}


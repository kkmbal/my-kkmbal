package portalxpert.board.education.mapper;

import java.util.List;
import java.util.Map;

import portalxpert.board.board100.vo.BbsBoardInfoVO;
import portalxpert.board.board100.vo.BbsEdcReqInfoVO;
import portalxpert.board.board100.vo.BbsEdcTgtInfoVO;
import portalxpert.board.board100.vo.BbsNotiAddItemInfoVO;
import portalxpert.board.board100.vo.BbsNotiApndFileVO;
import portalxpert.board.board100.vo.BbsNotiDelInfoVO;
import portalxpert.board.board100.vo.BbsNotiEvalInfoVO;
import portalxpert.board.board100.vo.BbsNotiInfoVO;
import portalxpert.board.board100.vo.BbsNotiOpnVO;
import portalxpert.board.board100.vo.BbsNotiSurveyVO;
import portalxpert.board.board100.vo.ComCodeSpecVO;
import portalxpert.board.board100.vo.TbsNotiDelInfoVO;
import portalxpert.common.vo.BoardSearchVO;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

/**
 * @author crossent
 *
 */
@Mapper("educationMapper")
public interface EducationMapper  {
	
	

	/**
     * 교육신청정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcReqDeptInfoList(BbsEdcReqInfoVO vo);
	
	/**
	 * 교육신청정보 조회
	 * @return BbsEdcReqInfoVO
	 * @exception Exception
	 * @auther crossent 
	 */
	public BbsEdcReqInfoVO getEdcReqInfo(BbsEdcReqInfoVO vo);

	/**
     * 교육대상정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcTgtInfoVO> getEdcTgtInfoList(BbsEdcReqInfoVO vo);

	/**
     * 교육신청건수 조회
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public Integer getEdcReqCnt(BbsNotiInfoVO vo);

	/**
     * 교육신청 추가
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int insertEdcReqInfo(BbsEdcReqInfoVO vo);

	/**
     * 교육신청대상 추가
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int insertEdcTgtInfo(BbsEdcTgtInfoVO vo);

	/**
     * 교육신청 삭제
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int deleteEdcReqInfo(BbsEdcReqInfoVO vo);

	/**
     * 교육대상 삭제
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int deleteEdcTgtInfo(BbsEdcReqInfoVO vo);

	/**
     * 교육신청수정
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int updateEdcReqInfo(BbsEdcReqInfoVO vo);

	/**
     * 교육신청정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcReqInfoManageList(BoardSearchVO boardSearchVO);

	/**
     * 교육신청정보 조회 총건수
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int getEdcReqInfoManageListTotCnt(BoardSearchVO boardSearchVO);

	/**
     * 교육대상정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcTgtInfoManageList(BoardSearchVO boardSearchVO);

	/**
     * 교육대상정보 조회 총건수
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int getEdcTgtInfoManageListTotCnt(BoardSearchVO boardSearchVO);

	/**
     * 교육대상정보 조회(엑셀)
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcTgtInfoManageListExcel(BoardSearchVO boardSearchVO);

	/**
     * 교육신청 동일건 조회
     * @return BbsEdcReqInfoVO
     * @exception Exception
     * @auther crossent 
     */
	public BbsEdcReqInfoVO getEdcReqEqualList(BbsEdcReqInfoVO vo);
	
	/**
     * 교육신청 대기건 중 승인대상 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcReqApprovalList(BbsEdcReqInfoVO vo);	
	
	/**
     * 교육신청정보 상세화면조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcReqInfoViewList(BbsEdcReqInfoVO vo);

    
}


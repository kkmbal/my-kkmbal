package portalxpert.board.education.sc;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import portalxpert.board.board100.vo.BbsBoardInfoVO;
import portalxpert.board.board100.vo.BbsEdcReqInfoVO;
import portalxpert.board.board100.vo.BbsEdcTgtInfoVO;
import portalxpert.board.board100.vo.BbsNotiAddItemInfoVO;
import portalxpert.board.board100.vo.BbsNotiApndFileVO;
import portalxpert.board.board100.vo.BbsNotiEvalInfoVO;
import portalxpert.board.board100.vo.BbsNotiInfoVO;
import portalxpert.board.board100.vo.BbsNotiOpnVO;
import portalxpert.board.board100.vo.ComCodeSpecVO;
import portalxpert.board.board100.vo.TbsNotiDelInfoVO;
import portalxpert.common.vo.BoardSearchVO;


public interface EducationService {
	

	/**
     * 교육신청정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcReqDeptInfoList(BbsEdcReqInfoVO reqInfo) throws Exception;
	
	/**
	 * 교육신청정보 조회
	 * @return BbsEdcReqInfoVO
	 * @exception Exception
	 * @auther crossent 
	 */
	public BbsEdcReqInfoVO getEdcReqInfo(BbsEdcReqInfoVO reqInfo) throws Exception;

	/**
     * 교육대상정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcTgtInfoVO> getEdcTgtInfoList(BbsEdcReqInfoVO reqInfo) throws Exception;

	/**
     * 교육신청건수 조회
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int getEdcReqCnt(BbsNotiInfoVO vo) throws Exception;

	/**
     * 교육신청저장
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public void insertEdcReq(String data, String reqStatCode, HttpSession session) throws Exception;

	/**
     * 교육신청삭제
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int deleteEdcReq(BbsEdcReqInfoVO vo) throws Exception;

	/**
     * 교육신청마감
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public void updateEdcReqEnd(BbsNotiAddItemInfoVO vo) throws Exception;

	/**
     * 교육신청 반려
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public void updateEdcReq(BbsEdcReqInfoVO vo) throws Exception;

	
	/**
     * 교육신청정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcReqInfoManageList(BoardSearchVO boardSearchVO) throws Exception;

	/**
     * 교육신청정보 조회 총건수
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int getEdcReqInfoManageListTotCnt(BoardSearchVO boardSearchVO) throws Exception;

	/**
     * 교육대상정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcTgtInfoManageList(BoardSearchVO boardSearchVO) throws Exception;

	/**
     * 교육대상정보 조회 총건수
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int getEdcTgtInfoManageListTotCnt(BoardSearchVO boardSearchVO) throws Exception;

	/**
     * 교육대상정보 조회(엑셀)
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcTgtInfoManageListExcel(BoardSearchVO boardSearchVO)  throws Exception;
    
	/**
     * 교육신청정보 상세화면조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcReqInfoViewList(BbsEdcReqInfoVO vo)  throws Exception;
	
	/**
     * 교육신청 동일건 조회
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public BbsEdcReqInfoVO getEdcReqEqualList(String data) throws Exception;	
	
	/**
	 * 교육신청 대기건 승인처리
	 * @return List<BbsEdcReqInfoVO>
	 * @exception Exception
	 * @auther crossent 
	 */
	public List<BbsEdcReqInfoVO> updateEdcReqApproval(BbsEdcReqInfoVO vo) throws Exception;
	


}

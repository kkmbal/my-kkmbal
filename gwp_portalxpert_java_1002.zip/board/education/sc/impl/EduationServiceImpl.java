package portalxpert.board.education.sc.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import portalxpert.board.board100.mapper.Board100Mapper;
import portalxpert.board.board100.vo.BbsEdcReqInfoVO;
import portalxpert.board.board100.vo.BbsEdcTgtInfoVO;
import portalxpert.board.board100.vo.BbsNotiAddItemInfoVO;
import portalxpert.board.board100.vo.BbsNotiInfoVO;
import portalxpert.board.education.mapper.EducationMapper;
import portalxpert.board.education.sc.EducationService;
import portalxpert.common.config.Constant;
import portalxpert.common.exception.PortalxpertException;
import portalxpert.common.utils.CommUtil;
import portalxpert.common.vo.BoardSearchVO;
import portalxpert.common.vo.UserInfoVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;



@Service("educationService")
public class EduationServiceImpl extends EgovAbstractServiceImpl implements  EducationService {
	
    @Resource(name="educationMapper")
    private EducationMapper educationMapper;
    
    /** board100Mapper */
    @Resource(name="board100Mapper")
    private Board100Mapper board100Mapper;
    
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
	private final static Logger logger = LoggerFactory.getLogger(EduationServiceImpl.class); 


	/**
     * 교육신청정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcReqDeptInfoList(BbsEdcReqInfoVO vo)	throws Exception {
    	try{
    		return educationMapper.getEdcReqDeptInfoList(vo);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}
	
	/**
	 * 교육신청정보 조회
	 * @return BbsEdcReqInfoVO
	 * @exception Exception
	 * @auther crossent 
	 */
	public BbsEdcReqInfoVO getEdcReqInfo(BbsEdcReqInfoVO vo)	throws Exception {
		try{
			return educationMapper.getEdcReqInfo(vo);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}

	/**
     * 교육대상정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcTgtInfoVO> getEdcTgtInfoList(BbsEdcReqInfoVO vo)	throws Exception {
    	try{
    		return educationMapper.getEdcTgtInfoList(vo);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}

	/**
     * 교육신청건수 조회
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int getEdcReqCnt(BbsNotiInfoVO vo) throws Exception {
    	try{
    		if(CommUtil.isEmpty(vo.getNotiId())){
    			throw new PortalxpertException("noti_id is null");
    		}
    		Integer edcReqCnt = educationMapper.getEdcReqCnt(vo);
    		if(edcReqCnt == null){
    			return 0;
    		}else{
    			return edcReqCnt;
    		}
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}

	/**
     * 교육신청저장
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public void insertEdcReq(String data, String reqStatCode, HttpSession session) throws Exception {
    	try{
    		JSONObject bbsObject = JSONObject.fromObject(data);
    		UserInfoVO info = (UserInfoVO)session.getAttribute("pxLoginInfo");

    		String reqSeq = bbsObject.getString("reqSeq");
    		
    		BbsEdcReqInfoVO vo = new BbsEdcReqInfoVO();
    		vo.setNotiId(bbsObject.getString("notiId"));
    		vo.setReqSeq(reqSeq);
    		vo.setDeptCode(bbsObject.getString("deptCode"));
    		vo.setEdcDttm(bbsObject.getString("edcDttm"));
    		vo.setEdcTimeDiv(bbsObject.getString("edcTimeDiv"));
    		vo.setReqStatCode(reqStatCode); //정상:Y, 대기:W
    		vo.setRegrId(info.getId());
			
    		if(CommUtil.isEmpty(reqSeq)){
    			educationMapper.insertEdcReqInfo(vo);
    		}else{
    			BbsEdcReqInfoVO edcReqInfo = educationMapper.getEdcReqInfo(vo);
    			//날짜가 다르면 수정을 신규로 처리한다.
    			if(vo.getEdcDttm().equals(edcReqInfo.getEdcDttm())){
    				vo.setReqStatCode(edcReqInfo.getReqStatCode());
    				
    				String edcType = bbsObject.getString("edcType");
    				if("020".equals(edcType)){ //방문교육
    					String edcTimeDiv = bbsObject.getString("edcTimeDiv");
						//시간만 다르면 추가신청으로 처리.
						if(!edcTimeDiv.equals(edcReqInfo.getEdcTimeDiv())){
							//추가
							educationMapper.insertEdcReqInfo(vo);
						}
					}else{
						educationMapper.updateEdcReqInfo(vo);
					}
    				
    			}else{
    				educationMapper.insertEdcReqInfo(vo);
    			}
    		}
    		
    		BbsEdcTgtInfoVO tgtVo = new BbsEdcTgtInfoVO();
    		tgtVo.setNotiId(vo.getNotiId());
			tgtVo.setReqSeq(vo.getReqSeq());
			tgtVo.setRegrId(vo.getRegrId());
			educationMapper.deleteEdcTgtInfo(vo);
			
			JSONArray jsonArr = (JSONArray)bbsObject.get("tgtInfo");
			tgtVo = null;
			for (int i=0; i < jsonArr.size(); i++)
			{
				tgtVo = new BbsEdcTgtInfoVO();
				JSONObject obj = (JSONObject)jsonArr.get(i);
				tgtVo.setNotiId(vo.getNotiId());
				tgtVo.setReqSeq(vo.getReqSeq());
				tgtVo.setUserName(obj.getString("userName"));
				tgtVo.setTelenumber(obj.getString("telenumber"));
				tgtVo.setRegrId(info.getId());
				
				educationMapper.insertEdcTgtInfo(tgtVo);
			}
    		
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}

	/**
     * 교육신청삭제
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int deleteEdcReq(BbsEdcReqInfoVO vo) throws Exception {
    	try{
    		educationMapper.deleteEdcReqInfo(vo);
    		
    		BbsEdcTgtInfoVO tgtVo = new BbsEdcTgtInfoVO();
    		tgtVo.setNotiId(vo.getNotiId());
			tgtVo.setReqSeq(vo.getReqSeq());
			tgtVo.setRegrId(vo.getRegrId());
			return educationMapper.deleteEdcTgtInfo(vo);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}

	/**
     * 교육신청마감
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public void updateEdcReqEnd(BbsNotiAddItemInfoVO vo) throws Exception {
    	try{
    		vo.setNotiItem("EDC_END_YN");
    		vo.setNotiItemVal("Y");
    		board100Mapper.updateBbsNotiAddItem(vo);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}

	/**
     * 교육신청반려
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public void updateEdcReq(BbsEdcReqInfoVO vo) throws Exception {
    	try{
    		vo.setReqStatCode("N"); //반려
			
    		educationMapper.updateEdcReqInfo(vo);
    		
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}

	/**
     * 교육신청정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcReqInfoManageList(BoardSearchVO boardSearchVO) throws Exception {
    	try{
    		return educationMapper.getEdcReqInfoManageList(boardSearchVO);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}

	/**
     * 교육신청정보 조회 총건수
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int getEdcReqInfoManageListTotCnt(BoardSearchVO boardSearchVO) throws Exception {
		try{
    		return educationMapper.getEdcReqInfoManageListTotCnt(boardSearchVO);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}

	/**
     * 교육대상정보 조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcTgtInfoManageList(BoardSearchVO boardSearchVO) throws Exception{
    	try{
    		return educationMapper.getEdcTgtInfoManageList(boardSearchVO);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}

	/**
     * 교육대상정보 조회 총건수
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public int getEdcTgtInfoManageListTotCnt(BoardSearchVO boardSearchVO) throws Exception{
		try{
    		return educationMapper.getEdcTgtInfoManageListTotCnt(boardSearchVO);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}
	
	/**
     * 교육대상정보 조회(엑셀)
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcTgtInfoManageListExcel(BoardSearchVO boardSearchVO) throws Exception{
    	try{
    		return educationMapper.getEdcTgtInfoManageListExcel(boardSearchVO);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}

	/**
     * 교육신청정보 상세화면조회
     * @return List<BbsEdcReqInfoVO>
     * @exception Exception
     * @auther crossent 
     */
	public List<BbsEdcReqInfoVO> getEdcReqInfoViewList(BbsEdcReqInfoVO vo)	throws Exception {
    	try{
    		return educationMapper.getEdcReqInfoViewList(vo);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}


	/**
     * 교육신청 동일건 조회
     * @return int
     * @exception Exception
     * @auther crossent 
     */
	public BbsEdcReqInfoVO getEdcReqEqualList(String data) throws Exception {
    	try{
    		JSONObject bbsObject = JSONObject.fromObject(data);

    		BbsEdcReqInfoVO vo = new BbsEdcReqInfoVO();
    		vo.setNotiId(bbsObject.getString("notiId"));
    		vo.setDeptCode(bbsObject.getString("deptCode"));
    		vo.setEdcDttm(bbsObject.getString("edcDttm"));
    		vo.setEdcTimeDiv(bbsObject.getString("edcTimeDiv"));
    		
    		return educationMapper.getEdcReqEqualList(vo);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}	
	

	/**
	 * 교육신청 대기건 승인처리
	 * @return BbsEdcReqInfoVO
	 * @exception Exception
	 * @auther crossent 
	 */
	public List<BbsEdcReqInfoVO> updateEdcReqApproval(BbsEdcReqInfoVO vo)	throws Exception {
    	try{
    		BbsNotiInfoVO notiInfo = new BbsNotiInfoVO();
    		notiInfo.setNotiId(vo.getNotiId());
    		notiInfo.setRegDttm(vo.getEdcDttm());
    		int edcReqCnt = 0;
    		Integer cnt = educationMapper.getEdcReqCnt(notiInfo); //신청가능인원수
    		if(cnt > 0){
    			edcReqCnt = cnt;
    		}
    		if(edcReqCnt > 0){
    			//최신신청 순 목록에서 신청가능인원수에 해당되는 대기건수를 승인처리함.
	    		List<BbsEdcReqInfoVO> edcReqApprovalList = educationMapper.getEdcReqApprovalList(vo);
	    		BbsEdcReqInfoVO upVO = null;
	    		for(BbsEdcReqInfoVO reqVO : edcReqApprovalList){
	    			edcReqCnt = edcReqCnt - Integer.parseInt(reqVO.getEdcTgtCnt());
	    			if(edcReqCnt > 0){
		    			upVO = new BbsEdcReqInfoVO();
		    			upVO.setNotiId(reqVO.getNotiId());
		    			upVO.setReqSeq(reqVO.getReqSeq());
		    			upVO.setRegrId(vo.getRegrId());
		    			upVO.setReqStatCode("Y");
		    			educationMapper.updateEdcReqInfo(upVO);
	    			}else{
	    				break;
	    			}
	    		}
	    		return edcReqApprovalList;
    		}else{
    			return null;
    		}
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}	
	


	
}

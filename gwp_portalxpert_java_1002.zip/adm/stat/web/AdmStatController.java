/**
 * 
 */
package portalxpert.adm.stat.web;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import portalxpert.adm.stat.sc.AdmStatService;
import portalxpert.adm.stat.vo.AdmStatBBSVO;
import portalxpert.adm.stat.vo.AdmStatSearchVO;
import portalxpert.adm.stat.vo.AdmStatSurveyVO;
import portalxpert.adm.stat.vo.AdmStatUseVO;
import portalxpert.common.config.Constant;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;


/**
 * @author yoDJ
 *
 */
@Controller
@RequestMapping(value="portalxpert/board/adm/stat")
public class AdmStatController {
	
	/** AdmStatService */
	@Resource(name = "admStatService")
	private AdmStatService admStatService;
	
    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    //@Resource(name="messageSourceAccessor")
    //private MessageSourceAccessor messageSource;

	//private final static Logger logger = LoggerFactory.getLogger(AdmStatController.class);
	

	
	
	/**
	 * 게시판 통계 조회
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "getAdmBbsStatList")
	public String getAdmBbsStatList(@ModelAttribute("admStatSearchVO") AdmStatSearchVO admStatSearchVO ,ModelMap modelMap) throws Exception{
		
		/** PropertyService.sample */
		admStatSearchVO.setPageUnit(admStatSearchVO.getPageUnit());
		admStatSearchVO.setPageSize(propertiesService.getInt("pageSize"));
		admStatSearchVO.setPageIndex(admStatSearchVO.getPageIndex());
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(admStatSearchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(admStatSearchVO.getPageUnit());
		paginationInfo.setPageSize(admStatSearchVO.getPageSize());
		
		admStatSearchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		admStatSearchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		admStatSearchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		admStatSearchVO.setsFromDt(admStatSearchVO.getsFromDt().replaceAll("[-,]", ""));
		admStatSearchVO.setsToDt(admStatSearchVO.getsToDt().replaceAll("[-,]", ""));

//		admStatSearchVO.setSearchCondition(admStatSearchVO.getSearchCondition());
//		admStatSearchVO.setSearchKeyword(admStatSearchVO.getSearchUseYn());
		
		List<AdmStatBBSVO> notiList = admStatService.getAdmBbsStatList(admStatSearchVO);
		int totCnt = admStatService.getAdmBbsStatListTotCnt(admStatSearchVO);
		
		paginationInfo.setTotalRecordCount(totCnt);
		
		for(AdmStatBBSVO vo : notiList){
			if(vo.getBoardKind().equals(Constant.BOARD_KIND_010.getVal())){
				vo.setBoardKind("일반");
			}else if(vo.getBoardKind().equals(Constant.BOARD_KIND_020.getVal())){
				vo.setBoardKind("폐쇄");
			}else if(vo.getBoardKind().equals(Constant.BOARD_KIND_030.getVal())){
				vo.setBoardKind("경조사");
			}else if(vo.getBoardKind().equals(Constant.BOARD_KIND_110.getVal())){
				vo.setBoardKind("설문");
			}else if(vo.getBoardKind().equals(Constant.BOARD_KIND_120.getVal())){
				vo.setBoardKind("CMS");
			}else if(vo.getBoardKind().equals(Constant.BOARD_KIND_130.getVal())){
				vo.setBoardKind("QnA");
			}
			
			if(vo.getBoardForm().equals(Constant.BOARD_FORM_010.getVal())){
				vo.setBoardForm("리스트형");
			}else if(vo.getBoardForm().equals(Constant.BOARD_FORM_020.getVal())){
				vo.setBoardForm("SNS형");
			}else if(vo.getBoardForm().equals(Constant.BOARD_FORM_030.getVal())){
				if(vo.getBoardFormSpec().equals(Constant.BOARD_FORM_SPEC_010.getVal())){
					vo.setBoardForm("이미지형");
				}else if(vo.getBoardFormSpec().equals(Constant.BOARD_FORM_SPEC_020.getVal())){
					vo.setBoardForm("동영상형");
				}
			}else if(vo.getBoardForm().equals(Constant.BOARD_FORM_040.getVal())){
				vo.setBoardForm("달력형");
			}
		}
		modelMap.put("paginationInfo", paginationInfo);
		modelMap.put("admStatSearchVO", admStatSearchVO);
		modelMap.put("notiList", notiList);
		
		
		return "/portalxpert/adm/stat/admBbsStatList";
	}	

	
	/**
	 * 첫페이지
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "admFrame")
	public String getAdmSysBlank(ModelMap modelMap, @RequestParam(value="url", required=false) String url) throws Exception{
		modelMap.put("url", url);
		return "/portalxpert/adm/admFrame";
	}
}

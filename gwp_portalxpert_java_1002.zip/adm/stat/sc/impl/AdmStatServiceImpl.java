/**
 * 
 */
package portalxpert.adm.stat.sc.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import portalxpert.adm.stat.mapper.AdmStatMapper;
import portalxpert.adm.stat.sc.AdmStatService;
import portalxpert.adm.stat.vo.AdmStatBBSVO;
import portalxpert.adm.stat.vo.AdmStatSearchVO;
import portalxpert.common.config.Constant;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @author yoDJ
 *
 */
@Service("admStatService")
public class AdmStatServiceImpl extends EgovAbstractServiceImpl implements AdmStatService {

	/** AdmGenLinkManageMapper */
    @Resource(name="admStatMapper")
    private AdmStatMapper admStatMapper;
	

	
	
	/**
	 * 게시판 통계 조회
	 * @param searchForm
	 * @return
	 * @throws Exception
	 */
	public List<AdmStatBBSVO> getAdmBbsStatList(AdmStatSearchVO searchForm)	throws Exception {
		try{
			return admStatMapper.getAdmBbsStatList(searchForm);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}	
	
	/**
	 * 게시판 통계 총갯수
	 * @param searchForm
	 * @return
	 * @throws Exception
	 */
	public int getAdmBbsStatListTotCnt(AdmStatSearchVO searchForm) throws Exception {
		try{
			return admStatMapper.getAdmBbsStatListTotCnt(searchForm);
		}catch(Exception e){
			throw processException(Constant.E000001.getVal(), new String[]{e.toString(), this.getClass().getSimpleName()}, e);
		}
	}	
}

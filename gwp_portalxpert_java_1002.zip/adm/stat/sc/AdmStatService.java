/**
 * 
 */
package portalxpert.adm.stat.sc;

import java.util.List;

import portalxpert.adm.stat.vo.AdmStatBBSVO;
import portalxpert.adm.stat.vo.AdmStatSearchVO;

/**
 * @author yoDJ
 *
 */
public interface AdmStatService {


	
	/**
	 * 게시판 통계 조회
	 * @param searchForm
	 * @return
	 * @throws Exception
	 */
	public List<AdmStatBBSVO> getAdmBbsStatList(AdmStatSearchVO searchForm)	throws Exception;
	
	/**
	 * 게시판 통계 총갯수
	 * @param searchForm
	 * @return
	 * @throws Exception
	 */
	public int getAdmBbsStatListTotCnt(AdmStatSearchVO searchForm) throws Exception;
}

/**
 * 
 */
package portalxpert.adm.stat.mapper;

import java.util.List;

import portalxpert.adm.stat.vo.AdmStatBBSVO;
import portalxpert.adm.stat.vo.AdmStatSearchVO;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

/**
 * @author yoDJ
 *
 */
@Mapper("admStatMapper")
public interface AdmStatMapper {


	
	public List<AdmStatBBSVO> getAdmBbsStatList(AdmStatSearchVO searchForm);
	public int getAdmBbsStatListTotCnt(AdmStatSearchVO searchForm);

}
